<html>
<head>
<title>Login Form Design</title>
<style>
    body{
    margin: 0;
    padding: 0;
    background-image: url(pic1.jpg);
    background-repeat: no-repeat;
    background-size: cover;
    background-position: center;
    font-family: sans-serif;
    background-color:white;

}

.loginbox{
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
    width: 35%;
    height: 105%;
    background-color:white;
    color:grey;
    top: 15%;
    left: 32%;
    box-sizing: border-box;
    padding: 30px 30px;
    position: relative;
  margin-bottom: 20vh;
  border-radius: 3px;
}
.loginbox:hover{
  opacity: 1;
}
h1{
    margin-bottom:40px;
    padding: 0 0 20px;
    text-align: center;
    font-size: 22px;
}

.loginbox input{
    width: 100%;
    margin-bottom: 20px;
}
::placeholder{
  color:grey;
}

.loginbox input[type="text"]{
  margin-top:15px;
}
.loginbox input[type="number"]{
  margin-top:15px;
}
.loginbox input[type="email"]{
  margin-top:15px;
}
.loginbox input[type="text"], input[type="password"],input[type="number"],input[type="email"]
{
    border: none;
    border-bottom: 1px solid #fff;
    outline: none;
    height: 40px;
    color: grey;
    font-size: 16px;
    padding:10px;
    border-radius:3px;
    border: 1px solid grey;
}
.loginbox input[type="password"]{
  margin-top: 15px;
}
.loginbox input[type="text"]:hover, input[type="password"]:hover,input[type="number"]:hover,input[type="email"]:hover
{
box-shadow:2px 2px 5px  grey;
}
.loginbox input[type="submit"]
{
    border: none;
    outline: none;
    height: 40px;
    background:dodgerblue;
    color: white;
    font-size: 18px;
    border-radius: 20px;
    text-align: center;
    border:1px solid dodgerblue;
    margin-bottom: 20px;
}
.loginbox input[type="submit"]:hover
{
    cursor: pointer;
    background:white;
    color:grey;
    
    
}
.loginbox a{
    text-decoration: none;
    font-size:18px;
    line-height: 20px;
    color:grey;
    margin-left:0px;
    margin-bottom: 30px;
}
.loginbox a:hover{
  font-weight: bold;
}


#opt {
height:75px;
width:100%;
background-color:dodgerblue;
font-family:arial;
font-weight:bold;
border-bottom: 2px solid dodgerblue;
}
#opt ul{
text-decoration:none;
list-style:none;
}
#opt a{
float:right;
text-decoration:none;
color:white;
letter-spacing: 2px;
padding:25px 30px;
margin-left:0px;
font-family:arial;
}
#opt a:hover{
background-color:dodgerblue;
color:white;
font-size: 20px;

}
#opt a.active{
background-color:dodgerblue;
color:white;
font-size:23px;

}
*{
margin:0px;
padding:0px;
}
#logo{
    height:100%;
    width:15%;
    float: left;
    margin-left: 5%;
    margin-top:20px;
    color:white;
    font-family: verdana;
    font-size:25px;
    letter-spacing:2px;
}
#logo img{
  height:80%;
  width:100%;
}

</style>
<script>
    function check()
{

        var x1 = document.forms["form"]["n1"].value;
        
             re = /[0-9]/;
      if(!re.test(form.n1.value)) {
        alert("Name must not contain numbers");
        form.n1.focus();
        return false;
      }

      else {}


        var x2 = document.forms["form"]["n2"].value;
     re = /^\w+$/;

        if(!re.test(form.n2.value)) {
        alert("Username is invalid");
        form.n2.focus();
        return false;
      }

      else {}

        
var x3 = document.forms["form"]["n3"].value;
var x4 = document.forms["form"]["n4"].value;

if( x3 !== x4){
    alert("passwords didn't match");
    form.n3.focus();
    return false;
}

var x5 = document.forms["form"]["n5"].value;
re = /^\d{10}$/;
    if(!re.test(form.x5.value)) {
        alert("mobile is invalid");
        form.n4.focus();
        return false;
      }

      else {}
 window.location="create-user.php";
}

</script>
</head>
    <body>
<div id="opt">
    <div id="logo">IDM Wallet</div>
<nav>
<ul>
<li><a href="signin.php" class="active">LOGIN</a></li>
<li><a href="home.php#three">CONTACT US</a></li>
<li><a href="home.php#two">ABOUT US</a></li>
<li><a href="home.php" >HOME</a></li>

</ul>
</nav>
</div>

    
    <div class="loginbox">
    
        <h1>Enter details</h1>
        <form  method="POST"   name="form" action="create-user.php" >
            
            <input type="text" placeholder="Name" name="n1" required>

            <input type="text" placeholder="Username" name="n2" required>
            
            <input type="password" placeholder="Password" name="n3" required>

            <input type="number" placeholder="Mobile number" name="n5" required>

            <input type="email" placeholder="Email" name="n6" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" required>

            <input type="submit" name="submit" value="Create account">
            </form>
            <a href="signin.php">Already have a account?</a>
        
        
    </div>
</body>
</head>
</html>
