<html>
<head>
<title>Login Form Design</title>
<style>
    body{
    margin: 0;
    padding: 0;
    background-image: url(pic1.jpg);
    background-repeat: no-repeat;
    background-size: cover;
    background-position: center;
    font-family: sans-serif;
    background-color:white;

}

.loginbox{
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
    width: 30%;
    height: 55%;
    background-color:white;
    color:dodgerblue;
    top: 45%;
    left: 50%;
    transform: translate(-50%,-50%);
    box-sizing: border-box;
    padding: 30px 30px;
    position: relative;
  -webkit-animation: mymove 3s;  /* Safari 4.0 - 8.0 */
  -webkit-animation-fill-mode: forwards; /* Safari 4.0 - 8.0 */
  animation: mymove 2s;
  animation-fill-mode: forwards;

  border-radius: 3px;
}
.loginbox:hover{
  opacity: 1;
}
@-webkit-keyframes mymove {
  from {left: 0px;}
  to {left: 50%; }
}

@keyframes mymove {
  from {left: 0px;}
  to {left: 50%;}
}


h1{
    margin: 0;
    padding: 0 0 20px;
    text-align: center;
    font-size: 22px;
}

.loginbox input{
    width: 100%;
    margin-bottom: 20px;
}
::placeholder{
  color:dodgerblue;
}
.loginbox input[type="text"]{
  margin-top:40px;
}
.loginbox input[type="text"], input[type="password"]
{
    border: none;
    border-bottom: 1px solid #fff;
    outline: none;
    height: 40px;
    color: grey;
    font-size: 16px;
    padding:10px;
    border-radius: 3px;
    border: 1px solid dodgerblue;
}
.loginbox input[type="password"]{
  margin-top: 15px;
}
.loginbox input[type="text"]:hover, input[type="password"]:hover
{
box-shadow:2px 2px 5px  grey;
}
.loginbox input[type="submit"]
{
    border: none;
    outline: none;
    height: 40px;
    background:dodgerblue;
    color: white;
    font-size: 18px;
    border-radius: 20px;
    text-align: center;
    border:1px solid dodgerblue;
    margin-bottom: 30px;
}
.loginbox input[type="submit"]:hover
{
    cursor: pointer;
    background:white;
    color:dodgerblue;
    
    
}
.loginbox a{
    text-decoration: none;
    font-size:18px;
    line-height: 20px;
    color:dodgerblue;
    margin-left:0px;

}
.loginbox a:hover{
  font-weight: bold;
}


#opt {
height:75px;
width:100%;
background-color:dodgerblue;
font-family:arial;
font-weight:bold;
border-bottom: 2px solid dodgerblue;
}
#opt ul{
text-decoration:none;
list-style:none;
}
#opt a{
float:right;
text-decoration:none;
color:white;
letter-spacing: 2px;
padding:25px 30px;
margin-left:0px;
font-family:arial;
}
#opt a:hover{
background-color:dodgerblue;
color:white;
font-size: 20px;

}
#opt a.active{
background-color:dodgerblue;
color:white;
font-size:23px;

}
*{
margin:0px;
padding:0px;
}
#logo{
    height:100%;
    width:15%;
    float: left;
    margin-left: 5%;
    margin-top:20px;
    color:white;
    font-family: verdana;
    font-size:25px;
    letter-spacing:2px;
}
#logo img{
  height:80%;
  width:100%;
}

</style>
<body>
    <body>
<div id="opt">
    <div id="logo">IDM Wallet</div>
<nav>
<ul>
<li><a href="signin.php" class="active">LOGIN</a></li>
<li><a href="home.php#three">CONTACT US</a></li>
<li><a href="home.php#two">ABOUT US</a></li>
<li><a href="home.php" >HOME</a></li>

</ul>
</nav>
</div>

    
    <div class="loginbox">
    
        <h1> Admin Login</h1>
        <form   method="POST">
            
            <input type="text" placeholder="Admin " name="n1">
            
            <input type="password" placeholder="Password" name="n2">
            
            <input type="submit" name="submit" value="Login">
            </form>
        
        
    </div>

</body>
</head>
</html>

<?php

$uname=filter_input(INPUT_POST,'n1');
$pass=filter_input(INPUT_POST,'n2');
$submit=filter_input(INPUT_POST,'submit');

if(!empty($submit))
{

    $dbservername="localhost";
    $dbusername="root";
    $dbpassword="";
    $dbname="data";
    $conn=mysqli_connect($dbservername,$dbusername,$dbpassword,$dbname);
    

    $sql="SELECT * FROM admins WHERE username='$uname'";
    $result=mysqli_query($conn,$sql);
    $row= mysqli_fetch_assoc($result);

            if($pass == $row['password'])
            {
                 
                  if($uname == $row['username'])
                    session_start();
                    $_SESSION['username']=$uname;
                    header("Location:alandingpage.php");
            }
           
}           