 <?php

$name=filter_input(INPUT_POST,'n1');
$phone=filter_input(INPUT_POST,'n5');
$uname=filter_input(INPUT_POST,'n2');
$pass=filter_input(INPUT_POST,'n3');
$submit=filter_input(INPUT_POST,'submit');
$Email=filter_input(INPUT_POST,'n6');

$len=mb_strlen($phone);

if ($len<10) 
        {
            echo"<script> alert('Mobile Number is invalid )</script>";
            //echo"<script> window.location='signup.php'</script>";
            exit();
        }

if(!empty($submit)){

include('connection.php');

    $sql="select * from users where username='$uname';";
    $result=mysqli_query($conn,$sql);
    $resultcheck=mysqli_num_rows($result);
    if( $resultcheck == '1')
        {
        echo"<script> alert('Please enter another username')</script>";
        //echo"<script> window.location='signup.php'</script>";
            exit();
        }         
    

    if(!preg_match("/^[a-zA-Z]+$/", $uname))
        {
            echo"<script> alert('Only use alphabets and number for username')</script>";      
            echo"<script> window.location='signup.php'</script>";
            exit();
        }
            
    $sql1="INSERT INTO users (name,mobile,email,username,password) values('$name','$phone','$Email','$uname','$pass')";
        mysqli_query($conn,$sql1);

        $sql2="CREATE TABLE record (
        username VARCHAR(30) ,
        Aadharcard BIGINT(12),
        Debitcard BIGINT(16),
        Creditcard BIGINT(16),
        Drivinglicense VARCHAR(16),
        Pancard BIGINT(10),
        Interht BIGINT(10),
        tenthht BIGINT(10),
        Voterid VARCHAR(10),
        Passport VARCHAR(8),
        Rationcard VARCHAR(25),
        Bankac1 BIGINT(13),
        Bankac2 BIGINT(13),
        Bankac3 BIGINT(13)
        )";  
        mysqli_query($conn,$sql2);
        echo mysqli_error($conn);

        $sql3="INSERT INTO record (username) values('$name')";
        mysqli_query($conn,$sql3);

         $sql4="INSERT INTO security (username) values('$name')";
        mysqli_query($conn,$sql4);
        

        
  echo"<script>alert('your account has been created')</script>";
  echo "<script> window.location = 'signin.php'</script>";
            exit();

}