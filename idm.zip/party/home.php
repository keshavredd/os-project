<html>
<head>
<title>Login Form Design</title>
<style>
    body{
    margin: 0;
    padding: 0;
    background-image: url(pic1.jpg);
    background-repeat: no-repeat;
    background-size: cover;
    background-position: center;
    font-family: sans-serif;
    background-color:white;

}

.loginbox{
    width: 30%;
    height: 60%;
    background-color:white;
    color:dodgerblue;
    top: 45%;
    left: 50%;
    transform: translate(-50%,-50%);
    box-sizing: border-box;
    padding: 30px 30px;
    position: relative;
  -webkit-animation: mymove 3s;  /* Safari 4.0 - 8.0 */
  -webkit-animation-fill-mode: forwards; /* Safari 4.0 - 8.0 */
  animation: mymove 2s;
  animation-fill-mode: forwards;
box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  border-radius:5px;
}
.loginbox:hover{
  opacity: 1;
}
@-webkit-keyframes mymove {
  from {left: 0px;}
  to {left: 50%; }
}

@keyframes mymove {
  from {left: 0px;}
  to {left: 50%;}
}


h1{
    margin: 0;
    padding: 0 0 20px;
    text-align: center;
    font-size: 22px;
}

.loginbox input{
    width: 100%;
    margin-bottom: 20px;
}
::placeholder{
  color:grey;
}

.loginbox input[type="text"]{
  margin-top:40px;
}
.loginbox input[type="text"], input[type="password"]
{
    border: none;
    border-bottom: 1px solid #fff;
    outline: none;
    height: 40px;
    color: dodgerblue;
    font-size: 16px;
    padding:10px;
    border-radius: 3px;
    border: 1px solid dodgerblue
}
.loginbox input[type="password"]{
  margin-top: 15px;
}
.loginbox input[type="text"]:hover, input[type="password"]:hover
{
box-shadow:2px 2px 5px  grey;
}
.loginbox input[type="submit"]
{
    border: none;
    outline: none;
    height: 40px;
    background:dodgerblue;
    color: white;
    font-size: 18px;
    border-radius: 20px;
    text-align: center;
    border:1px solid dodgerblue;
    margin-bottom: 30px;
}
.loginbox input[type="submit"]:hover
{
    cursor: pointer;
    background:white;
    color:dodgerblue;
    
    
}
.loginbox a{
    text-decoration: none;
    font-size:18px;
    line-height: 20px;
    color:dodgerblue;
    margin-left:0px;

}
.loginbox a:hover{
  font-weight: bold;
}


#opt {
height:75px;
width:100%;
background-color:dodgerblue;
font-family:arial;
font-weight:bold;
border-bottom: 2px solid dodgerblue;
box-shadow: 2px 2px 10px rgba(0,0,0,0.5);
}
#opt ul{
text-decoration:none;
list-style:none;
}
#opt a{
float:right;
text-decoration:none;
color:white;
letter-spacing: 2px;
padding:25px 30px;
margin-left:0px;
font-family:arial;
}
#opt a:hover{
background-color:dodgerblue;
color:white;
font-size: 20px;

}
#opt a.active{
background-color:dodgerblue;
font-size:23px;

}
*{
margin:0px;
padding:0px;
}
#logo{
    height:100%;
    width:20%;
    float: left;
    margin-left: 5%;
    margin-top:20px;
    color:white;
    font-family: verdana;
    font-size:25px;
    letter-spacing:2px;
}

#logo p{
margin-left:70px;
}
#one{
    height:80vh;
    width:95%;

}

#left{
    height:70vh;
    width:40%;
    float:right;
    margin-top:17vh;
    margin-left: 0px;
    color:dodgerblue;
    font-size:70px;
    letter-spacing:5px;
}
#right{
    margin-top:7vh;
    height:90%;
    width:35%;
    float:left;
    margin-left:10%;
}
#right img{
    height:100%;
    width:100%;
}
#two
{
    height:80vh;
    width:90%;
    background-color:dodgerblue;
    margin-top:5%;
    padding-left:10%;
    padding-right:0px;
}
#two img{
    height:200px;
    width:200px;
}
#top{
    height:15%;
    width:70%;
    color: white;
    font-size:50px;
    font-family:verdana;
}
#d1{
    margin-left:50px;
    height:40%;
    width:80%;
}
#d2{
height:30%;
width:20%;
float:left;
}
#d3{
height:70%;
width:50%;
float:left;
margin-left:20%;
color:white;
font-family: verdana;
letter-spacing:2px;
}
#d4{margin-left:50px;
    margin-top:10px;
 height:40%;
    width:80%;   

}
#d5{
height:30%;
width:20%;
float:left;    
}
#d6{
height:70%;
width:50%;
float:left;
margin-left:20%;
color:white;
font-family: verdana;
letter-spacing:2px;   
}
#twotwo{
    height:20%;
    width:100%;
    background-color:dodgerblue;
}
#three{
    height:50%;
    width:100%;
    background-color: #4dc3ff;
    text-align: left;
}
#three p{
    padding-top:10px;
}
#stay{
    color:white; 
    font-size:50px;
    font-family: verdana;
    margin-left: 15%;
    text-align: left;
}
#contact{
    height:50%;
    width:100%;
    color:white;
    margin-left:15%;
    margin-top:2%;
}
#c3{
    font-size:25px;
    font-family: veradana;
    letter-spacing: 2px;
    float:left;
    padding-left:40px;
}
#c2{
    font-size:25px;
    font-family: veradana;
    letter-spacing: 2px;
    float:left;
    border-right:3px solid white;
    height:55%;
    padding-left:40px;
    padding-right:40px;
}
#c1{
    font-size:25px;
    font-family: veradana;
    letter-spacing: 2px;
    float:left;
    border-right:3px solid white;
    height:55%;
    padding-right:40px;
}
#four{
    height:40%;
    width:100%;
    background-color:#70dbdb;
}
#idm{
    color:white; 
    font-size:30px;
    font-family: verdana;
    margin-left: 15%;
    padding-top:0px;
}
#box{
    height:60%;
    width:40%;
    color:white;
    float:right;
    margin-right:15%;   
}
#links{
    height:100%;
    width:35%;
    border-top: 3px solid white;
    float:left;
    margin-left:5%;
}
#links a{
    text-decoration: none;
    color:white;
    padding-left:30px;
}
#about{
    height:100%;
    width:35%;
    border-top: 3px solid white;
    float: left;
    margin-left:15%;
}
#about p{
    padding-left: 30px;
}
#social{
    height:100%;
    width:25%;
    border-top: 3px solid white;
    float: left;
    margin-left:5%;
}
#social img{
    height:25px;
    width:25px;
}
</style>
<body>
    <body>
<div id="opt">
    <div id="logo"><p>IDM Wallet</p></div>
<nav>
<ul>
<li><a href="signin.php" >LOGIN</a></li>
<li><a href="#three">CONTACT US</a></li>
<li><a href="#two">ABOUT US</a></li>
<li><a href="home.php" class="active">HOME</a></li>
</ul>
</nav>
</div>
<div id="one"> 
    <div id="left"><p>SECURE & RELIABLE REAL-TIME DATA</p></div>
    <div id="right"><img src="security-lock.png"></div>
</div>        
    
<div id="two">
    <div id="top">MEET IDM WALLET</div>
    <div id="d1">
        <div id="d2"><img src="meet.png"></div>
        <div id="d3"><h2>OUR STORY</h2><br><p>WE HERE  ARE TO HELP PEOPLE SAVE THEIR IDENTITIES ONLINE SO THAT TO PROVIDE ACCESS TO THEIR OWN DETAILS WHERE EVER THEY GO. EASE OF CARRYING USERS DATA IS IMPOTANT THESE DAYS. SO OUR PROJECT PROVIDES EASY ACCES TO THEIR SAVED DATA</p></div>
    </div>

    <div id="d4">
        <div id="d5"><img src="vision.png"></div>
        <div id="d6"><h2>OUR VISION</h2><br><p>TO PROVIDE SECURITY TO WHATEVER THE USER SAVES IN THEIR ACCOUNTS.

            TO CREATE ONLINE DATABASE AND AVOID PAPER WORK HEADACHE

            TO PROVIDE EASE TO ACCESS THE DETAILS WHEREVER OR WHENEVER THE USER WANT

            </p></div>
    </div>
</div>



<div id="three">
    <div id="stay"><p>STAY IN <BR>TOUCH<BR></p></div>
    <div id="contact">
        <div id="c1">Gmail:<br>idmwallet5@gmail.com</div>
        <div id="c2">phn:<br>6284401310<br>9542664939</div>
        <div id="c3">LOVELY PROFESSIONAL<br> UNIVERSITY <br>Phagwara, Punjab , <br>144411</div>
     </div>
</div>

<div id="threeth"></div>

<div id="four">
    <div id="idm"><br>IDM Wallet</div>
    <div id="box">
        <div id="links"><br>
            LINKS<br><br>
            <a href="signin.php">sign-in</a><br><br>
            <a href="signup.php">sign-up</a><br><br>
            <a href="admin_login.php">Admin</a><br><br>
        </div>
        <div id="about"><br>
            ABOUT<br><br><p>
            LOVELY PROFESSIONAL UNIVERSITY
            Phagwara, Punjab , 144411</p>
        </div>
        
</div>

</body>
</head>
</html>
