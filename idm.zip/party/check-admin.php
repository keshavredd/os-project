<?php

$uname=filter_input(INPUT_POST,'n1');
$pass=filter_input(INPUT_POST,'n2');
$submit=filter_input(INPUT_POST,'submit');

if(!empty($submit))
{

    $dbservername="localhost";
    $dbusername="root";
    $dbpassword="";
    $dbname="data";
    $conn=mysqli_connect($dbservername,$dbusername,$dbpassword,$dbname);
    

    $sql="SELECT * FROM admins WHERE username='$uname'";
    $result=mysqli_query($conn,$sql);
    $row= mysqli_fetch_assoc($result);

            if($pass == $row['password'])
            {
                 
                    session_start();
                    $_SESSION['username']=$uname;
                    echo"<script>window.location='alandingpage.php'<script>";
            }
           else{
                    echo"<script>alert('userame or password wrong');</script>";
                    echo"<script>window.location = 'admin_login.php'</script>";                
            }
           
}           