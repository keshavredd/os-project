<?php
session_start();

$name=$_SESSION['username'];
$q1 = $_POST["q1"];
$q2 = $_POST["q2"];
$q3 = $_POST["q3"];

include('connection.php');

$sql1="UPDATE  security  SET qone = '$q1' where username = '$name' ";
 mysqli_query($conn,$sql1);
$sql2="UPDATE  security  SET qtwo = '$q2' where username = '$name' ";
 mysqli_query($conn,$sql2);
$sql3="UPDATE  security  SET qthree = '$q3' where username = '$name' ";
 mysqli_query($conn,$sql3);
 		
echo"<script>alert('Thank you!!')</script>";

//header("location:userprofile.php");