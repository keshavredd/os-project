<html>
<head>
<title>Login Form Design</title>
<style>
    
#opt {
height:75px;
width:100%;
background-color:dodgerblue;
font-family:arial;
font-weight:bold;
border-bottom: 2px solid dodgerblue;
}
#opt ul{
text-decoration:none;
list-style:none;
}
#opt a{
float:right;
text-decoration:none;
color:white;
letter-spacing: 2px;
padding:25px 30px;
margin-left:0px;
font-family:arial;
}
#opt a:hover{
background-color:dodgerblue;
color:white;
font-size: 20px;

}
#opt a.active{
background-color:dodgerblue;
color:white;
font-size:23px;

}
*{
margin:0px;
padding:0px;
}
#logo{
    height:100%;
    width:15%;
    float: left;
    margin-left: 5%;
    margin-top:20px;
    color:white;
    font-family: verdana;
    font-size:25px;
    letter-spacing:2px;
}
#logo img{
  height:80%;
  width:100%;
}
.utable{
    margin-top:100px;
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    padding:10px;
    margin-left:30%;
    border-collapse: collapse;
    letter-spacing: 1px;
color:grey;
}
th{
    padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  color:grey;

}
table ,td ,th{
    border: 1px solid #ddd;
    padding:10px;
    border-collapse: collapse;
}
.utable tr:nth-child(odd){background-color: #f2f2f2;}

.utable tr:hover {background-color: #ddd;}
h2{
    color:grey;
    margin-top:100px;
}
</style>
<body>
    <body>
<div id="opt">
    <div id="logo">IDM Wallet</div>
<nav>
<ul>
<li><a href="logout.php">Logout</a></li>

</ul>
</nav>
</div>
<br>
<h2><center>Active Users</center> </h2>
<?php

include('connection.php');

$sql ="SELECT * FROM users";
$result = mysqli_query($conn,$sql);
$queryResults = mysqli_num_rows($result);

if ($queryResults > 0) {
    
    echo "<table class='utable'><th>Name</th><th>Userame</th><th>Email</th><th>Mobile</th>";
    while($row=mysqli_fetch_assoc($result))
    {
      echo "<tr>
            <td>".$row['name']."</td>
            <td>".$row['username']."</td>
            <td>".$row['email']."</td>
            <td>".$row['mobile']."</td></tr>";
    }
    echo "</table>";
  }
 
?>
</body>
</head>
</html>
