<?php
session_start();
?>
<html>
<head>
<title>Login Form Design</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link href="https://stackpath.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" />
<link href="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.9/dist/css/bootstrap-select.min.css" rel="stylesheet"/>
<script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.9/dist/js/bootstrap-select.min.js"></script>

<style>
.loginbox{
    width: 30%;
    height: 60%;
    background-color:white;
    color:grey;
    top: 45%;
    left: 50%;
    transform: translate(-50%,-50%);
    box-sizing: border-box;
    padding: 30px 30px;
    position: relative;
  -webkit-animation: mymove 3s;  /* Safari 4.0 - 8.0 */
  -webkit-animation-fill-mode: forwards; /* Safari 4.0 - 8.0 */
  animation: mymove 2s;
  animation-fill-mode: forwards;
box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  border-radius:5px;
}
.loginbox:hover{
  opacity: 1;
}
@-webkit-keyframes mymove {
  from {left: 0px;}
  to {left: 50%; }
}

@keyframes mymove {
  from {left: 0px;}
  to {left: 50%;}
}


h1{
    margin: 0;
    padding: 0 0 20px;
    text-align: center;
    font-size: 22px;
}

.loginbox input{
    width: 100%;
    margin-bottom: 20px;
}
::placeholder{
  color:grey;
}

.loginbox input[type="text"]{
  margin-top:40px;
}
.loginbox input[type="text"], input[type="password"]
{
    border: none;
    border-bottom: 1px solid #fff;
    outline: none;
    height: 40px;
    color:grey;
    font-size: 16px;
    padding:10px;
    border-radius: 3px;
    border: 1px solid grey;
}
.loginbox input[type="password"]{
  margin-top: 15px;
}
.loginbox input[type="text"]:hover, input[type="password"]:hover
{
box-shadow:2px 2px 5px  grey;
}
.loginbox input[type="submit"]
{
    border: none;
    outline: none;
    height: 40px;
    background:dodgerblue;
    color: white;
    font-size: 18px;
    border-radius: 20px;
    text-align: center;
    border:1px solid dodgerblue;
    margin-bottom: 30px;
}
.loginbox input[type="submit"]:hover
{
    cursor: pointer;
    background:white;
    color:grey;
    
    
}
.loginbox a{
    text-decoration: none;
    font-size:18px;
    line-height: 20px;
    color:grey;
    margin-left:0px;

}
.loginbox a:hover{
  font-weight: bold;
  color:grey;
}


#opt {
height:75px;
width:100%;
background-color:dodgerblue;
font-family:arial;
font-weight:bold;
border-bottom: 2px solid dodgerblue;
box-shadow: 2px 2px 5px rgba(0,0,0,0);
}
#opt ul{
text-decoration:none;
list-style:none;
}
#opt a{
float:right;
text-decoration:none;
color:white;
letter-spacing: 2px;
padding:25px 30px;
margin-left:0px;
font-family:arial;
font-size: 20px;
}
#opt a:hover{
color:white;
font-size: 23px;

}
#opt a.active{
color:white;
font-size:23px;

}
*{
margin:0px;
padding:0px;
}
#logo{
    height:100%;
    width:20%;
    float: left;
    margin-left: 5%;
    margin-top:20px;
    color:white;
    font-family: verdana;
    font-size:25px;
    letter-spacing:2px;
}
#logo img{

  height:60%;
  width:20%;
}
#logo p{
margin-top:0px;
margin-left:70px;
}
#udata input[type="text"]
{
    border: none;
    border-bottom: 1px solid #fff;
    outline: none;
    height: 35px;
    color: grey;
    font-size: 16px;
    padding:10px;
    border-radius:3px;
    border:1px solid lightgrey ;
    margin-bottom: 20px;
}
#udata input[type="submit"]
{
    height:40px;
    width:220px;
    background:dodgerblue;
    color: white;
    font-size: 18px;
    text-align: center;
   border:none;
   padding: 10px;
   margin-top:20px;
   border-radius:3px;
}
#udata
{
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
margin-top:150px;
height:300px;
width:350px;
padding:20px;
padding-left: 60px;
margin-left:35%;
}
.answer{
    margin-top:20px;
}
html{
    background-color:dodgerblue;
}
body{
    background-color: white;
}

</style>
<body>
    <body>
<div id="opt">
    <div id="logo"><p>IDM Wallet</p></div>
<nav>
<ul>
<li><a href="signin.php" class="active">LOGIN</a></li>
<li><a href="home.php#three">CONTACT US</a></li>
<li><a href="home.php#two">ABOUT US</a></li>
<li><a href="home.php" >HOME</a></li>

</ul>
</nav>
</div>

    
   <div id="data">
<div id="udata">
    <form method="POST" action="update-password.php">
       <br> 
       <input type="text" name="password" placeholder="Password"><br>
        <input type="text" name="cnfmpass" placeholder="Re-Enter passowrd" class="answer"><br>
        <input type="submit" name="submit">
    </form>

</div>

</div>
</body>
</head>
</html>