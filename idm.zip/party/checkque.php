<?php
$q1 = $_POST["q1"];
$q2 = $_POST["q2"];
$q3 = $_POST["q3"];

include('connection.php');
session_start();
$_SESSION['user']=$q1;
 $sql1="SELECT * FROM security where username = '$q1'";
 $result=mysqli_query($conn,$sql1);
$row= mysqli_fetch_assoc($result);

 if($q3==$row['qone'])
 {
 echo"<script>window.location = 'change-password.php'</script>";
 }
 elseif($q3==$row['qtwo'])
 {
 echo"<script>window.location = 'change-password.php'</script>";
 }
 elseif($q3==$row['qthree'])
 {
 echo"<script>window.location = 'change-password.php'</script>";
 }
 else{
 echo"<script>alert('sorry your answer does not mathch')</script>";
 }
?>