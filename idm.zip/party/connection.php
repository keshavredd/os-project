
<?php
$dbservername="localhost";
$dbusername="root";
$dbpassword="";
$dbname="data";
$conn=mysqli_connect($dbservername,$dbusername,$dbpassword,$dbname);
?>