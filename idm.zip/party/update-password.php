<?php

session_start();

$qone = $_POST["password"];
$qtwo = $_POST["cnfmpass"];
$qthree = $_POST["submit"];

$username=$_SESSION['user'];
include('connection.php');

if($qone==$qtwo){
$sql1="UPDATE users set password='$qone' where username = '$username'";
mysqli_query($conn,$sql1);
echo mysqli_error($conn);
}
echo"<script>alert('Your password has been changed')</script>";
echo"<script>window.location = 'signin.php'</script>";
?>
