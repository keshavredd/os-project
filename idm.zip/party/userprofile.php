<?php
session_start();
?>
<html>
<head>
<style>
#opt {
height:75px;
width:100%;
background-color:dodgerblue;
font-family:arial;
font-weight:bold;
border-bottom: 2px solid dodgerblue;
}
#opt ul{
text-decoration:none;
list-style:none;
}
#opt a{
float:right;
text-decoration:none;
color:white;
letter-spacing: 2px;
padding:25px 30px;
margin-left:0px;
font-family:arial;
font-size: 20px;
}
#opt a:hover{
color:white;
font-size: 23px;

}
#opt a.active{
background-color:dodgerblue;
color:white;
font-size:23px;

}
*{
margin:0px;
padding:0px;
}
#logo{
    height:100%;
    width:15%;
    float: left;
    margin-left: 5%;
    margin-top:20px;
    color:white;
    font-family: verdana;
    font-size:25px;
    letter-spacing:2px;
}
::placeholder{
    color:lightgrey;
}

input[type="file"] {
    display: none;
}

.custom-file-upload {
    border-radius:3px;
    height:20px;
    width:200px;
    text-align:center;
    border: 1px solid #ccc;
    display: inline-block;
    padding: 6px 12px;
    background-color: dodgerblue;
    color:black;
    font-family: verdana;
    font-size: 15px;
    cursor: pointer;
}
table{
    margin-top:100px;
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    padding:10px;
    margin-left:30%;
    border-collapse: collapse;
    letter-spacing: 1px;
color:grey;
}
th{
    padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  color:grey;

}
table ,td ,th{
    border: 1px solid #ddd;
    padding:10px;
    border-collapse: collapse;
}
table tr:nth-child(odd){background-color: #f2f2f2;}

table tr:hover {background-color: #ddd;}
#que{
    height:auto;
    width:70%;
    font-family:verdana;
    font-size:15px;
    letter-spacing: 1px;
    background-color:rgba(255,0,0,0.5);
    padding:15px;
    margin-left: 15%;
    border:2px solid red;
    margin-top:50px;
    text-align:center;
}
#questions{
    height:auto;
    font-family:verdana;
    width:50%;
    font-size:15px;
    letter-spacing: 1px;
    background-color:#e6ffff;
    padding:15px;
    margin-left:25%;
    margin-top:50px;
    text-align:center;
    margin-bottom: 5%;
      box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}
#questions input[type="text"]
{

    border:none;
    border:1px solid lightgrey;
    outline: none;
    height: 40px;
    width:60%;
    color: grey;
    font-size: 16px;
    padding:10px;
    border-radius:3px;
    margin-top:10px;
    margin-bottom:10px;

}
#questions input[type="text"]:hover
{
box-shadow:2px 2px 5px  grey;
}
#user-details input[type="submit"]
{
    border-radius:3px;
    height:33px;
    width:100px;
    text-align:center;
    border: 1px solid #ccc;
    display: inline-block;
    padding: 6px 12px;
    background-color: dodgerblue;
    color:black;
    font-family: verdana;
    font-size: 15px;
    cursor: pointer;   
    margin-left:20%;
}
#questions input[type="submit"]
{
    border-radius:3px;
    height:33px;
    width:100px;
    text-align:center;
    border: 1px solid #ccc;
    display: inline-block;
    padding: 6px 12px;
    background-color: dodgerblue;
    color:black;
    font-family: verdana;
    font-size: 15px;
    cursor: pointer;   
    margin-left:calc(50%-50px);
}
</style>
</head>
<body>
<div id="opt">
    <div id="logo">IDM Wallet</div>
<nav>
<ul>
<li><a href="logout.php">Logout</a></li>
<li><a href="userprofile.php" class="active">Profile</a></li>
</ul>
</nav>
</div>


<?php
include('connection.php');
$search= $_SESSION['username'];
$sql ="SELECT * FROM users Where  username = '$search'";
$result = mysqli_query($conn,$sql);
$queryResults = mysqli_num_rows($result);

if ($queryResults > 0) {
    $row=mysqli_fetch_assoc($result);

echo"<div id='user-details'>
<table><tr><td><p>Username:-".$row['username']."</p></td><td rowspan='3'>";
if($row['profilepic']==''){
echo" <img src='profile.jpg' id='img'></td></tr>";
}
else{
    echo"<img src=".$row['profilepic']."></td></tr>";
}
echo"
<tr><td><p>Mobile:-".$row['mobile']."</p></td></tr>
<tr><td><p>Email:-".$row['email']."</p></td></tr>
<tr><td colspan='2'>
<form action='profile-submit.php' enctype='multipart/form-data' method='POST'>
<label class='custom-file-upload'>
    <input type='file' name='image'>Update profile picture</label>
    <input type='submit' value='Save' name='submit'></form>
    </td></tr>
    </td></tr></table></div>
";
}


$sql2 ="SELECT * FROM security Where  username = '$search'";
$result2 = mysqli_query($conn,$sql2);
$queryResults2 = mysqli_num_rows($result2);

if ($queryResults2 > 0) {
    $row=mysqli_fetch_assoc($result2);
if($row['qone']==''){

if($row['qtwo']==''){

if($row['qthree']==''){

echo"<div id='que'>
<p>In case you forget your password this security questions will help you reset your password</p>
</div>
<div id='questions'>

<form action='questions-submit.php' method='POST'>
What is your first crush's name ?<br>
<input type='text' name='q1' required><br>

What is your nick name ?<br>
<input type='text' name='q2' required><br>

What is your favourite sport ?<br>
<input type='text' name='q3' required><br>
<input type='submit' value='Submit' name='submit'> 
</form>

</div>";


}
}
}
}


?>
