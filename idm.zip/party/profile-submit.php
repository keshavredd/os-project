<?php
session_start();

$name=$_SESSION['username'];
$filename = $_FILES["image"]["name"];
$tempname = $_FILES["image"]["tmp_name"];
$folder = "images/".$filename;

move_uploaded_file($tempname, $folder);

include('connection.php');

$sql="UPDATE  users  SET profilepic = '$folder' where username = '$name' ";
 mysqli_query($conn,$sql);
 		
echo"<script>alert('profile picture updated ')</script>";

header("location:userprofile.php");