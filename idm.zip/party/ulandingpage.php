<?php
session_start();
?>
<html>
<head>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link href="https://stackpath.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" />
<link href="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.9/dist/css/bootstrap-select.min.css" rel="stylesheet"/>
<script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.9/dist/js/bootstrap-select.min.js"></script>
<style>
#opt {
height:75px;
width:100%;
background-color:dodgerblue;
font-family:arial;
font-weight:bold;
border-bottom: 2px solid dodgerblue;
}
#opt ul{
text-decoration:none;
list-style:none;
}
#opt a{
float:right;
text-decoration:none;
color:white;
letter-spacing: 2px;
padding:25px 30px;
margin-left:0px;
font-family:arial;
font-size: 20px;
}
#opt a:hover{
color:white;
font-size: 23px;

}
#opt a.active{
background-color:dodgerblue;
color:white;
font-size:23px;

}
*{
margin:0px;
padding:0px;
}
#logo{
    height:100%;
    width:15%;
    float: left;
    margin-left: 5%;
    margin-top:20px;
    color:white;
    font-family: verdana;
    font-size:25px;
    letter-spacing:2px;
}
#logo img{
  height:80%;
  width:100%;
}
#udata input[type="text"]
{
    border: none;
    border-bottom: 1px solid #fff;
    outline: none;
    height: 35px;
    color: grey;
    font-size: 16px;
    padding:10px;
    border-radius:3px;
    border:1px solid lightgrey ;
    margin-top: 20px;
}
#udata input[type="submit"]
{
    height: 40px;
    width:220px;
    background:dodgerblue;
    color: white;
    font-size: 18px;
    text-align: center;
   border:none;
   padding: 10px;
   margin-top:20px;
   border-radius:3px;
}
#udata
{
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
margin-top:150px;
height:230px;
width:350px;
padding:20px;
padding-left: 60px;
margin-left:35%;
}

html{
    background-color:dodgerblue;
}
body{
    background-color: white;
}
.utable{
    margin-top:100px;
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    padding:10px;
    margin-left:0%;
    border-collapse: collapse;
    letter-spacing: 1px;
color:grey;
}
th{
    padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  color:grey;

}
table ,td ,th{
    border: 1px solid #ddd;
    padding:10px;
    border-collapse: collapse;
}
.utable tr:nth-child(odd){background-color: #f2f2f2;}

.utable tr:hover {background-color: #ddd;}
::placeholder{
    color:lightgrey;
}
</style>
</head>
<body>
<div id="opt">
    <div id="logo">IDM Wallet</div>
<nav>
<ul>
<li><a href="logout.php">Logout</a></li>
<li><a href="userprofile.php">Profile</a></li>

</ul>
</nav>
</div>
<div id="data">
<div id="udata">
    <form method="POST">
       <br> <select name="n1" class="selectpicker">
            <option value="Aadhar card">Aadhar card</option>
            <option value="Debit card">Debit card</option>
            <option value="Credit card">Credit card</option>
            <option value="Driving license">Driving license</option>
            <option value="Pan card">Pan card</option>
            <option value="Inter hall-ticket">Inter hall-ticket</option>
            <option value="10th hall-ticket">10th hall-ticket</option>
            <option value="Voter id">Voter id</option>
            <option value="Passport">Passport</option>
            <option value="Ration card">Ration card</option>
            <option value="Bank account number(1)">Bank account number(1)</option>
            <option value="Bank account number(2)">Bank account number(2)</option>
            <option value="Bank account number(3)">Bank account number(3)</option>            
        </select><br>
        <input type="text" name="n2" placeholder="Enter details"><br>
        <input type="submit" name="submit">
    </form>

</div>

</div>
</body>
</head>
</html>
<?php


include('connection.php');


$name = $_SESSION['username'];

$file=filter_input(INPUT_POST,'n1');
$data=filter_input(INPUT_POST,'n2');
$submit=filter_input(INPUT_POST,'submit');


if(!empty($submit)){

    if($file=="Aadhar card")
    {
        if(!preg_match("/^[1-9]{1}[0-9]{11}/", $data))
        {
            echo"<script> alert('Please enter valid data')</script>";            
        }
        else
        {
            if($data<=999999999999){
            $sql1="UPDATE  record  SET Aadharcard = '$data' where username = '$name' ";
            mysqli_query($conn,$sql1);
            echo"<script>alert('your data has been saved')</script>";
            }else{
                echo"<script> alert('Please enter valid data')</script>";       
            }

        }
    }

    if($file=="Debit card")
    {
        if(!preg_match("/^[1-9]{1}[0-9]{15}/", $data))
        {
            echo"<script> alert('Please enter valid data')</script>";            
        }
        else
        {
            if($data<=9999999999999999){
            $sql1="UPDATE  record  SET Debitcard = '$data' where username = '$name' ";
            mysqli_query($conn,$sql1);
            echo"<script>alert('your data has been saved')</script>";
                    }
            else{
            echo"<script> alert('Please enter valid data')</script>";
            }
        }
    }

    if($file=="Credit card")
    {
        if(!preg_match("/^[1-9]{1}[0-9]{15}/", $data))
        {
            echo"<script> alert('Please enter valid data')</script>";            
        }
        else
        {
           if($data<=9999999999999999){
            $sql1="UPDATE  record  SET Creditcard = '$data' where username = '$name' ";
            mysqli_query($conn,$sql1);
            echo"<script>alert('your data has been saved')</script>";
                    }
            else{
            echo"<script> alert('Please enter valid data')</script>";
            }
        }
    }

    if($file=="Driving license")
    {
        if(!preg_match("/^[a-zA-Z1-9]{1}[a-zA-Z0-9]{15}/", $data))
        {
            echo"<script> alert('Please enter valid data')</script>";            
        }
        else
        {
            if(strlen($data)==16){
            $sql1="UPDATE  record  SET Drivinglicense = '$data' where username = '$name' ";
            mysqli_query($conn,$sql1);
            echo"<script>alert('your data has been saved')</script>";
            }
            else{
            echo"<script> alert('Please enter valid data')</script>";
            }
        }
    }
    if($file=="Pan card")
    {
        if(!preg_match("/^[a-zA-Z1-9]{1}[a-zA-Z0-9]{9}/", $data))
        {
            echo"<script> alert('Please enter valid data')</script>";            
        }
        else
        {   if(strlen($data)==10){
            $sql1="UPDATE  record  SET Pancard = '$data' where username = '$name' ";
            mysqli_query($conn,$sql1);
            echo"<script>alert('your data has been saved')</script>";
            }
            else{
            echo"<script> alert('Please enter valid data')</script>";
            }
        }
    }
    if($file=="Inter hall-ticket")
    {
        if(!preg_match("/^[1-9]{1}[0-9]{9}/", $data))
        {
            echo"<script> alert('Please enter valid data')</script>";            
        }
        else
        {   if($data<=9999999999){
            $sql1="UPDATE  record  SET Interht = '$data' where username = '$name' ";
            mysqli_query($conn,$sql1);
            echo"<script>alert('your data has been saved')</script>";
        } else{
            echo"<script> alert('Please enter valid data')</script>";
            }

        }
    }
    if($file=="10th hall-ticket")
    {
        if(!preg_match("/^[1-9]{1}[0-9]{9}/", $data))
        {
            echo"<script> alert('Please enter valid data')</script>";            
        }
        else
        {   
            if($data<=999999999999){
            $sql1="UPDATE  record  SET tenthht = '$data' where username = '$name' ";
            mysqli_query($conn,$sql1);
            echo"<script>alert('your data has been saved')</script>";
        } else{
            echo"<script> alert('Please enter valid data')</script>";
            }
        }
    }
    if($file=="Voter card")
    {
        if(!preg_match("/^[a-zA-Z1-9]{1}[a-zA-Z0-9]{9}/", $data))
        {
            echo"<script> alert('Please enter valid data')</script>";            
        }
        else
        {
            if(strlen($data)==10){
            $sql1="UPDATE  record  SET Voterid = '$data' where username = '$name' ";
            mysqli_query($conn,$sql1);
            echo"<script>alert('your data has been saved')</script>";
            }
            else{
            echo"<script> alert('Please enter valid data')</script>";
            }
        }
    }
    if($file=="Passport")
    {
        if(!preg_match("/^[a-zA-Z1-9]{1}[a-zA-Z0-9]{7}/", $data))
        {
            echo"<script> alert('Please enter valid data')</script>";            
        }
        else
        {if(strlen($data)==8){
            $sql1="UPDATE  record  SET Passport = '$data' where username = '$name' ";
            mysqli_query($conn,$sql1);
            echo"<script>alert('your data has been saved')</script>";
            }
            else{
            echo"<script> alert('Please enter valid data')</script>";
            }
        }
    }
    if($file=="Ration card")
    {
        if(!preg_match("/^[a-zA-Z1-9]{1}[a-zA-Z0-9]{24}/", $data))
        {
            echo"<script> alert('Please enter valid data')</script>";            
        }
        else
        {
            if(strlen($data)==25){
            $sql1="UPDATE  record  SET Rationcard = '$data' where username = '$name' ";
            mysqli_query($conn,$sql1);
            echo"<script>alert('your data has been saved')</script>";
            }else{
            echo"<script> alert('Please enter valid data')</script>";
            }
        }
    }
    if($file=="Bank account number(1)")
    {
        if(!preg_match("/^[1-9]{1}[0-9]{12}/", $data))
        {
            echo"<script> alert('Please enter valid data')</script>";            
        }
        else
        {
            if($data<=9999999999999){
            $sql1="UPDATE  record  SET Bankac1 = '$data' where username = '$name' ";
            mysqli_query($conn,$sql1);
            echo"<script>alert('your data has been saved')</script>";
        } else{
            echo"<script> alert('Please enter valid data')</script>";
            }
        }
    }
    if($file=="Bank account number(2)")
    {
        if(!preg_match("/^[1-9]{1}[0-9]{12}/", $data))
        {
            echo"<script> alert('Please enter valid data')</script>";            
        }
        else
        {
            if($data<=9999999999999){
            $sql1="UPDATE  record  SET Bankac2 = '$data' where username = '$name' ";
            mysqli_query($conn,$sql1);
            echo"<script>alert('your data has been saved')</script>";
            } else{
            echo"<script> alert('Please enter valid data')</script>";
            }
        }
    }
    if($file=="Bank account number(3)")
    {
        if(!preg_match("/^[1-9]{1}[0-9]{12}/", $data))
        {
            echo"<script> alert('Please enter valid data')</script>";            
        }
        else
        {
            if($data<=9999999999999){
            $sql1="UPDATE  record  SET Bankac3 = '$data' where username = '$name' ";
            mysqli_query($conn,$sql1);
            echo"<script>alert('your data has been saved')</script>";
        } else{
            echo"<script> alert('Please enter valid data')</script>";
            }
        }
    }

}

$sql5 ="SELECT * FROM record WHERE username = '$name'";
$result = mysqli_query($conn,$sql5);
if (!$result)
    echo(mysqli_error($conn));

$queryResults = mysqli_num_rows($result);

if ($queryResults > 0) {
    
    echo "<table class='utable'><th>Aadharcard</th><th>Debitcard</th><th>Creditcard</th><th>Driving license</th><th>Pan card</th><th>Inter hall-ticket</th><th>10th hall-ticket</th><th>Voter id</th><th>Passport</th><th>Bank account number(1)</th><th>Bank account number(2)</th><th>Bank account number(3)</th><th>Ration card</th>";
    while($row=mysqli_fetch_assoc($result))
    {
      echo "<tr>
            <td>".$row['Aadharcard']."</td>
            <td>".$row['Debitcard']."</td>
            <td>".$row['Creditcard']."</td>
            <td>".$row['Drivinglicense']."</td>
            <td>".$row['Pancard']."</td>
            <td>".$row['Interht']."</td>
            <td>".$row['tenthht']."</td>
            <td>".$row['Voterid']."</td>
            <td>".$row['Passport']."</td>
            <td>".$row['Bankac1']."</td>
            <td>".$row['Bankac2']."</td>
            <td>".$row['Bankac3']."</td>
             <td>".$row['Rationcard']."</td>
            </tr>";
    }
    echo "</table>";
  }

?>
