<?php
	$servername="localhost";
	$username="root";
	$pass="";

$conn1=mysqli_connect($servername,$username,$pass);
$sql="CREATE DATABASE data";	
mysqli_query($conn1,$sql);

$conn=mysqli_connect($servername,$username,$pass,"data");

$sql1="CREATE TABLE users (
 		name VARCHAR(30) NOT NULL,
 		mobile BIGINT(20) NOT NULL,
 		email VARCHAR(30) NOT NULL,
 		username VARCHAR(30) NOT NULL,
 		password VARCHAR(50) NOT NULL
 		)";  
mysqli_query($conn,$sql1);
$sql2="CREATE TABLE admins (
 		name VARCHAR(30) NOT NULL,
 		username VARCHAR(30) NOT NULL,
 		password VARCHAR(50) NOT NULL
 		)";  
mysqli_query($conn,$sql2);
echo "done";