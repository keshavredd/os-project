<!DOCTYPE html>
<html>
<head>
<style>
body{
margin:0px;
padding :0px;
background-color:#edf1f7;
}
#one{
height:50vh;
width:100%;
background-image:url(pic.jpg);
background-size:cover;

}
/*display:table;
background-attachment:fixed;
*/
#one2{
	background-color:black;
	height:100%;
	width:100%;
	opacity:0.6;
}
h1{
font-family:arial black;
font-size:70px;
color:white;
margin-top:100px;
text-align:center;
display:table-cell;
vertical-align:middle;
}

#opt {
height:75px;
width:100%;
background-color:white;
font-family:arial;
font-weight:bold;
}
#opt ul{
text-decoration:none;
list-style:none;
}
a{
float:right;
text-decoration:none;
color:red;
padding:20px 30px;
margin-left:30px;
font-family:arial;
}
a:hover{
background-color:white;
color:black;
border-bottom: 3px solid red;

}
a.active{
background-color:white;
color:black;
border-bottom: 3px solid red;

}
*{
margin:0px;
padding:0px;
}
#logo{
	height:100%;
	width:15%;
	float: left;
	margin-left: 5%;
	margin-top: 10px;
}
#logo img{
	height:80%;
	width:100%;
}

   	
.article-container{
width:80%;
margin-top:50px;
margin-left:10%;
height:auto;
margin-bottom :10vh;
}
   	
.search-container
{
	height:20vh;
	width:100%;
}
.search-container input[type="text"]
{
float:center;
margin-left:calc( 50% - 200px );
margin-top:15vh;
height:10px;
width:300px;
padding:10px;
border-radius:5px;
border:1px solid grey;
box-shadow:2px 2px 5px grey;
}
.search-container button{
	height:33px;
	width:80px;
	margin-bottom: -10px;
	background-color: dodgerblue;
	color:white;
	border:none;
	font-size:15px;
	border-radius: 3px;
	cursor: pointer;
}
.utable{
	border:2px solid black;
	padding:10px;
	margin-left:10%;

}
th{
	font-weight: bolder;
}
table ,td ,th{
	font-family: verdana;
	border:2px solid black;
	padding:10px;
	border-collapse: collapse;
}
tr:nth-child(even) {
  background-color: white;
}
</style>
</head>
<body>
<div id="opt">
	<div id="logo"><img src="company.png"></div>
<nav>
<ul>
<li><a href="logout.php">Log out</a></li>
<li><a href="admin_users.php">Users</a></li>
<li><a href="bookings.php" class="active">Bookings</a></li>
<li><a href="packages.php" >Packages</a></li>
<li><a href="alandingpage.php" > Add Packages</a></li>
</ul>
</nav>
</div>

<div id="one">
	<div id="one2"> 
	</div>
</div>

<div class="article-container">

<?php


$db = mysqli_connect("localhost", "root", "", "yatra");
$sql ="SELECT * FROM bookings";
$result = mysqli_query($db,$sql);
$queryResults = mysqli_num_rows($result);

if ($queryResults > 0) {
    
    echo "<table class='utable'><th>Place</th><th>Start date</th><th>Persons</th><th>Stay cost</th><th>Food cost</th><th>Traveling cost</th><th> Total cost</th><th>Username</th>";
    while($row=mysqli_fetch_assoc($result))
    {
      echo "<tr>
      		<td>".$row['Place']."</td> 		
      		<td>".$row['Startdate']."</td>
      		<td>".$row['Persons']."</td>
      		<td>".$row['Staycost']."</td>
      		<td>".$row['Foodcost']."</td>
      		<td>".$row['Travelingcost']."</td>
      		<td>".$row['Totalcost']."</td>
      		<td>".$row['Username']."</td>
      		</tr>";
    }
    echo "</table>";
  }
 
?>
</div>

</body>
</html>