<?php 
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<style>
body{
margin:0px;
padding :0px;
background-color:#edf1f7;
}
#one{
height:50vh;
width:100%;
background-image:url(pic.jpg);
background-size:cover;

}
/*display:table;
background-attachment:fixed;
*/
#one2{
	background-color:black;
	height:100%;
	width:100%;
	opacity:0.6;
}
h1{
font-family:arial black;
font-size:70px;
color:white;
margin-top:100px;
text-align:center;
display:table-cell;
vertical-align:middle;
}

#opt {
height:75px;
width:100%;
background-color:white;
font-family:arial;
font-weight:bold;
}
#opt ul{
text-decoration:none;
list-style:none;
}
a{
float:right;
text-decoration:none;
color:red;
padding:20px 30px;
margin-left:30px;
font-family:arial;
}
a:hover{
background-color:white;
color:black;
border-bottom: 3px solid red;

}
a.active{
background-color:white;
color:black;
border-bottom: 3px solid red;

}
*{
margin:0px;
padding:0px;
}
#logo{
	height:100%;
	width:15%;
	float: left;
	margin-left: 5%;
	margin-top: 10px;
}
#logo img{
	height:80%;
	width:100%;
}

#details{
	margin-left:35%;
	margin-top: 5%;
}
.class{
background-color:dodgerblue;
height:30px;
width:100px;
color:white;
font-family: verdana;
border-radius: 3px;
font-weight: bold;
font-size:15px;
margin-left: 20px;
border:none;
cursor:pointer;
}

</style>
</head>
<body>
<div id="opt">
	<div id="logo"><img src="company.png"></div>
<nav>
<ul>

<li><a href="logout.php">Log out</a></li>
<li><a href="ulandingpage" class="active">Packages</a></li>

</ul>
</nav>
</div>

<div id="one">
	<div id="one2"> 
	</div>
</div>
<div id="details">
	<form method="POST">
		<table>
		<tr><td>Name :-</td><td><input type="text" name="cname"><br></td></tr>
		<tr><td>Card number :- </td><td><input type="number" name="cardnumber">*16 digits<br></td></tr>
		<tr><td>cvv :- </td><td><input type="number" name="cvv">*3 digits<br></td></tr>
		<tr><td><input type="submit"  class='btn' name="submit" value="Pay"></td></tr>
	</table>
	</form>
</div>
</body>
</html>
<?php
$dbservername="localhost";
$dbusername="root";
$dbpassword="";
$dbname="yatra";
$conn=mysqli_connect($dbservername,$dbusername,$dbpassword,$dbname);

$cardholder_name=filter_input(INPUT_POST,'cname');
$cardnumber=filter_input(INPUT_POST,'cardnumber');
$cvv=filter_input(INPUT_POST,'cvv');
$submit=filter_input(INPUT_POST,'submit');

$destination=$_SESSION['place'];
$persons=$_SESSION['people'];
$stayamount=$_SESSION['stayamount'];
$startdate=$_SESSION['startdate'];
$travelcost=$_SESSION['travelcost'];
$foodcost=$_SESSION['foodcost'];
$total=$_SESSION['totalcost'];
$username=$_SESSION['username'];

if(!empty($submit)){
if(!empty($cardholder_name))
	{if(!empty($cardnumber))
		{if(!empty($cvv)){

			if (!preg_match("/^[0-9]{16}/", $cardnumber)) 
		{
			header("Location: debit.php");
			exit();
		}
			if (!preg_match("/^[0-9]{3}/", $cvv)) 
		{
			header("Location: debit.php");
			exit();
		}

				$sql1="INSERT INTO bookings values('$destination','$startdate','$persons','$stayamount','$foodcost','$travelcost','$total','$username')";
		mysqli_query($conn,$sql1);
		echo "<script>alert('Payment successful!!')</script>";
			echo "<script> window.location = 'receipt.php'</script>";


		}else{echo "<script>alert('Enter the cvv')</script>";
			echo "<script> window.location = 'debit.php'</script>";}
		}else{echo "<script>alert('Enter the cardnumber')</script>";
			echo "<script> window.location = 'debit.php'</script>";}
	}else{echo "<script>alert('Enter the cardholder name')</script>";
			echo "<script> window.location = 'debit.php'</script>";}


}

?>
