<!DOCTYPE html>
<html>
<head>
<style>
body{
margin:0px;
padding :0px;
background-color:#edf1f7;
}
#one{
height:50vh;
width:100%;
background-image:url(pic.jpg);
background-size:cover;

}
/*display:table;
background-attachment:fixed;
*/
#one2{
	background-color:black;
	height:100%;
	width:100%;
	opacity:0.6;
}
h1{
font-family:arial black;
font-size:70px;
color:white;
margin-top:100px;
text-align:center;
display:table-cell;
vertical-align:middle;
}

#opt {
height:75px;
width:100%;
background-color:white;
font-family:arial;
font-weight:bold;
}
#opt ul{
text-decoration:none;
list-style:none;
}
a{
float:right;
text-decoration:none;
color:red;
padding:20px 30px;
margin-left:30px;
font-family:arial;
}
a:hover{
background-color:white;
color:black;
border-bottom: 3px solid red;

}
a.active{
background-color:white;
color:black;
border-bottom: 3px solid red;

}
*{
margin:0px;
padding:0px;
}
#logo{
	height:100%;
	width:15%;
	float: left;
	margin-left: 5%;
	margin-top: 10px;

}
#logo img{
	height:80%;
	width:100%;
}

h2
{margin-left:15%;
padding:20px;
font-family: verdana;
line-height: 50px;
letter-spacing: 2px;
}
#details
{
height:85vh;
width:45%;
margin-left:25%;
margin-top: 5%;
background-color: white;
font-family:verdana;
padding-left:5%;
margin-bottom:10%;
border-radius: 5px;
}
#details td{
	padding-top: 20px;
}
table{
	width: 600px;
}
.btn
{
background-color:dodgerblue;
height:30px;
width:100px;
color:white;
font-family: verdana;
border-radius: 3px;
font-weight: bold;
font-size:15px;
margin-left: 20px;
border:none;
cursor:pointer;
}

</style>
</head>
<body>
<div id="opt">
	<div id="logo"><img src="company.png"></div>
<nav>
<ul>
<li><a href="logout.php">Log out</a></li>
<li><a href="admin_users.php">Users</a></li>
<li><a href="bookings.php">Bookings</a></li>
<li><a href="packages.php">Packages</a></li>
<li><a href="login.html" class="active"> Add Packages</a></li>

</ul>
</nav>
</div>
<div id="details">
	<h2 >Add Package Details</h2>
	<form  action="addpackage.php" method="POST" enctype="multipart/form-data">
	<table>
		<tr>
			<td>Package ID</td>
			<td><input type="number" name="pid"></td>
		</tr>
		
		<tr>
			<td>Add Place</td>
			<td><input type="text" name="destination"></td>
		</tr>
		
		<tr>
			<td>Distance to destination</td>
			<td><input type="number" name="distance"></td>
		</tr>

		<tr>
			<td>Stay Amount</td>
			<td><input type="number" name="stayamount"></td>
		</tr>
		
		<tr>
			<td>Food Amount</td>
			<td><input type="number" name="foodamount"></td>
		</tr>
		
		<tr>
			<td>Bus Amount</td>
			<td><input type="number" name="busamount"></td>
		</tr>
		
		<tr>
			<td>Train Amount</td>
			<td><input type="number" name="trainamount"></td>
		</tr>
		
		<tr>
			<td>Airplane Amount</td>
			<td><input type="number" name="airplaneamount"></td>
		</tr>
		
		<tr>
			<td>Add Image</td>
			<td><input type="file" name="image"></td>
		</tr>
		<tr>
			<td colspan="2">
				<center><input type="submit"  class="btn" name="submit"></center>
			</td>
		</tr>
	
	</table>
	
</div>

</body>
</html>