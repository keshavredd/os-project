<?php
	$servername="localhost";
	$username="root";
	$pass="";
//$conn=mysqli_connect($servername,$username,$pass);

//$sql="CREATE DATABASE yatra";	
//mysqli_query($conn,$sql);

$conn=mysqli_connect($servername,$username,$pass,"yatra");

$sql1="CREATE TABLE users (
 		name VARCHAR(30) NOT NULL,
 		mobile BIGINT(20) NOT NULL,
 		email VARCHAR(30) NOT NULL,
 		username VARCHAR(30) NOT NULL,
 		password VARCHAR(50) NOT NULL
 		)";  
mysqli_query($conn,$sql1);
$sql2="CREATE TABLE admins (
 		name VARCHAR(30) NOT NULL,
 		username VARCHAR(30) NOT NULL,
 		password VARCHAR(50) NOT NULL
 		)";  
mysqli_query($conn,$sql2);
$sql3="CREATE TABLE packages(
			pid INT(4) NOT NULL,
			destination VARCHAR(20),
			distance INT(5),
			stayamount INT(10),
			foodamount INT(10),
			busamount INT(10),
			trainamount INT(10),
			airplaneamount INT(10),
			image VARCHAR(100))";
			mysqli_query($conn,$sql3);



$sql4="INSERT INTO packages VALUES(2001,'mussoorie',200,500,500,800,600,1000,'mussoorie.jpg')";
mysqli_query($conn,$sql4);
// echo mysqli_error($conn);

$sql5="INSERT INTO packages VALUES(2002,'puducherry',300,500,500,200,800,500,'puducherry.jpg')";
mysqli_query($conn,$sql5);

$sql6="INSERT INTO packages VALUES(2003,'shimla',350,1000,500,800,600,500,'shimla.jpg')";
mysqli_query($conn,$sql6);

$sql7="INSERT INTO packages VALUES(2004,'manali',270,500,300,200,800,500,'manali.jpg')";
mysqli_query($conn,$sql7);

$sql8="INSERT INTO packages VALUES(2005,'varanasi',340,500,300,600,800,500,'varanasi.jpg')";
mysqli_query($conn,$sql8);

$sql9="INSERT INTO packages VALUES(2006,'kochi',390,500,500,180,200,500,'kochi.jpg')";
mysqli_query($conn,$sql9);

$sql10="CREATE TABLE bookings (
 		Place VARCHAR(30) NOT NULL,
 		Startdate DATE NOT NULL,
 		Persons INT(10) NOT NULL,
 		Staycost INT(10) NOT NULL,
 		Foodcost INT(10) NOT NULL,
 		Travelingcost INT(10) NOT NULL,
 		Totalcost INT(10) NOT NULL,
 		Username varchar(10) NOT NULL
 		)";  
mysqli_query($conn,$sql10);

$sql11="CREATE TABLE contact (
email VARCHAR(30))";
mysqli_query($conn,$sql11);
mysqli_error($conn);
echo"done";

?>		


