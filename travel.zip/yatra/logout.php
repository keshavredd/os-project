<?php
session_start();
echo$_SESSION['username'];
if(isset($_SESSION['username']))
{
	
$_SESSION['username']='';
header("Location:index.php");
}
?>