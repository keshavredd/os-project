<!DOCTYPE html>
<html>
<head>
<style>
body{
margin:0px;
padding :0px;
background-color:#edf1f7;
}
#one{
height:50vh;
width:100%;
background-image:url(pic.jpg);
background-size:cover;

}
/*display:table;
background-attachment:fixed;
*/
#one2{
	background-color:black;
	height:100%;
	width:100%;
	opacity:0.6;
}
h1{
font-family:arial black;
font-size:70px;
color:white;
margin-top:100px;
text-align:center;
display:table-cell;
vertical-align:middle;
}

#opt {
height:75px;
width:100%;
background-color:white;
font-family:arial;
font-weight:bold;
}
#opt ul{
text-decoration:none;
list-style:none;
}
a{
float:right;
text-decoration:none;
color:red;
padding:20px 30px;
margin-left:30px;
font-family:arial;
}
a:hover{
background-color:white;
color:black;
border-bottom: 3px solid red;

}
a.active{
background-color:white;
color:black;
border-bottom: 3px solid red;

}
*{
margin:0px;
padding:0px;
}
#logo{
	height:100%;
	width:15%;
	float: left;
	margin-left: 5%;
	margin-top: 10px;
}
#logo img{
  height:80%;
  width:100%;
}

   	.article-container{
   		width:80%;
   		margin-top: 100px;
margin-left:10%;
height:100vh;
   	}
   	.article-box{
   		 float:left;
         text-align: center;
   		width:30%;
         background-color: #f7f3f0;
margin-left:20px;
margin-top: 20px;
box-shadow:5px 5px 15px grey;
background-repeat: no-repeat;
color:black;
border-radius:5px;
}
.sbutton img{
   height:120%;
   width:100%;
 object-fit: cover;
 border-radius: 5px 5px 0px 0px;
}
.sbutton{
	border:0px;
	height:100%;
	width:100%;
	cursor: pointer;
	border-radius:5px;
}
.sbutton p{
	font-size:20px;
	font-family: verdana;
	padding-bottom: 5px;
}
.search-container
{
	height:20vh;
	width:100%;
}
.search-container input[type="text"]
{
float:center;
margin-left:calc( 50% - 200px );
margin-top:15vh;
height:10px;
width:300px;
padding:10px;
border-radius:5px;
border:1px solid grey;
box-shadow:2px 2px 5px grey;
}
.search-container button{
  height:33px;
  width:80px;
  margin-bottom: -10px;
  background-color: dodgerblue;
  color:white;
  border:none;
  font-size:15px;
  border-radius: 3px;
  cursor: pointer;
}

</style>
</head>
<body>
<div id="opt">
	<div id="logo"></div>
<nav>
<ul>
<li><a href="logout.php">Log out</a></li>
<li><a href="ulandingpage" class="active">Packages</a></li>
</ul>
</nav>
</div>

<div id="one">
	<div id="one2"> 
	</div>
</div>
<div class="search-container">
    <form action="searchpackages.php" method="POST">
      <input type="text" placeholder="Destination" name="search">
      <button type="submit" name="submit">search</button>
    </form>
  </div>

<div class="article-container">

<?php
$db = mysqli_connect("localhost", "root", "", "yatra");
if (isset($_POST['submit'])) 
{
$search=mysqli_real_escape_string($db,$_POST['search']);
$sql="SELECT * FROM packages WHERE destination LIKE '%$search%'";
$result = mysqli_query($db,$sql);
$queryResults = mysqli_num_rows($result);

if ($queryResults > 0) {
    
    while($row=mysqli_fetch_assoc($result))
    {
      echo"<div class='article-box'>
            <form method='POST' action='individual.php'>
            <input type= 'hidden' name='naam' value=".$row['destination'].">

            <button class='sbutton' type='submit'><img src=images/".$row['image'].">
           <br> <p>".$row['destination']."</p></button>
    </form></div>";
  
    }
  }
 }
?>
</div>
</body>
</html>