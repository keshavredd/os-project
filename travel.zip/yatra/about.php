<!DOCTYPE html>
<html>
<head>
<style>
body{
margin:0px;
padding :0px;
background-color:#edf1f7;
}
#one{
height:50vh;
width:100%;
background-image:url(pic.jpg);
background-size:cover;

}
/*display:table;
background-attachment:fixed;
*/
#one2{
	background-color:black;
	height:100%;
	width:100%;
	opacity:0.6;
}
h1{
font-family:arial black;
font-size:70px;
color:white;
margin-top:100px;
text-align:center;
display:table-cell;
vertical-align:middle;
}

#opt {
height:75px;
width:100%;
background-color:white;
font-family:arial;
font-weight:bold;
}
#opt ul{
text-decoration:none;
list-style:none;
}
a{
float:right;
text-decoration:none;
color:red;
padding:20px 30px;
margin-left:30px;
font-family:arial;
}
a:hover{
background-color:white;
color:black;
border-bottom: 3px solid red;

}
a.active{
background-color:white;
color:black;
border-bottom: 3px solid red;

}
*{
margin:0px;
padding:0px;
}
#logo{
	height:100%;
	width:15%;
	float: left;
	margin-left: 5%;
	margin-top: 10px;
}
#logo img{
	height:80%;
	width:100%;
}

#about
{
 background-color: white;
 width:80%;
 height:auto;
 margin-top: 100px;
 margin-bottom:100px;
 margin-left:10%;
 border-radius: 3px;
 padding:20px;
 padding-bottom: 75px;
 font-family: arial;
text-align: justify;
line-height: 30px;
word-spacing: 5px;
}
</style>
</head>
<body>
<div id="opt">
	<div id="logo"><img src="company.png"></div>
<nav>
<ul>

<li><a href="login.html">LOGIN</a></li>
<li><a href="contact.php">CONTACT US</a></li>
<li><a href="about.php" class="active">ABOUT US</a></li>
<li><a href="index.php">HOME</a></li>

</ul>
</nav>
</div>

<div id="one">
	<div id="one2"> 
	</div>
</div>
<div id="about">
<h2><center>ABOUT COMPANY</center></h2><br>
<P>We are a leading online travel company in India providing a 'best in class' customer experience with the goal to be 'India's Travel Planner'. Through our website,  our mobile applications and our other associated platforms, leisure and business travelers can explore, research, compare prices and book a wide range of services catering to their travel needs. Since our inception in 2006, more than 7 million customers have used one or more of our comprehensive travel-related services, which include domestic and international air ticketing, hotel bookings, homestays, holiday packages, bus ticketing, rail ticketing, activities and ancillary services. With over 83,000 hotels contracted across India, we are India's largest platform for domestic hotels.
</p><br>
<p>A strong and "trusted" travel brand of India, our strengths include a large and loyal customer base, a multi-channel platform for leisure and business travelers, a robust mobile eco-system for a spectrum of travelers and suppliers, a strong technology platform designed to deliver a high level of scalability and innovation and a seasoned senior management team comprising of industry executives with deep roots in the travel industry in India and abroad.
</p><br>
<p> is one of India's most well-recognized and awarded brands. Among others, we have won multiple awards from the Ministry of Tourism, Government of India, including the National Tourism Award for "Outstanding Performance as a Domestic Tour Operator" in Category I (Rest of India) for the assessment year 2014-15; three awards at the India Tourism Awards for 'Outstanding performance as a Domestic Tour Operator (Rest of India)','Outstanding performance as a Domestic Tour Operator in Jammu and Kashmir' and 'Outstanding performance as an Inbound Tour Operator-Cat C in 2013 & the 'Best Domestic Tour Operator' award in 2010. Some other industry awards are: ET ("Economic Times") Brand Equity's Most Trusted Online Travel Brand of 2015; Travel & Hospitality named us the Most Outstanding Online Company: business to consumer or B2C; and in 2014,  In 2013, we were recognized by Matrixlab as the Most Popular Brand in Travel & Leisure Category and in 2012,  in IAMAI's Annual India Digital Awards.</p>
<br><P>The acquisition of companies, intellectual property and talented individuals has been central to our growth strategy. In 2010, we acquired TSI and its subsidiaries in order to expand our B2B business, particularly our international air ticketing for small and medium scale enterprises. In 2012, we acquired Travelguru B2B and B2C entities from Travelocity, which remain well-established hotel aggregators in India. Through this acquisition, we expanded our hotel business by establishing more direct hotel relationships in India and improved our inventory of affordable travel options. Recently, we also acquired Air Travel Bureau Ltd. ("ATB"), India's largest independent corporate travel services provider to further strengthen our position in the growing corporate travel market in India. Now, with this combined entity,  We have also leveraged our leading position in the Indian travel ecosystem to make several "acqui-hires", including the teams from mGaadi and dudegenie, in order to grow our business.</P>
<br><P>We are dedicated to ensuring a superior user experience on our platform and a critical component of that is customer service. We provide customer support at all stages of our customer's journey – before, during and after. Our customer "touch-points" include our website, mobile platforms, retail stores, call centres, a network of over 17,000 agents across India addressing the needs of a large fragmented market of travel agents and a portfolio of B2E clients across India employing over 4 million people.

</P>
</div>
</body>
</html>