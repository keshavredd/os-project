<?php
	$servername="localhost";
	$username="root";
	$pass="";
	$dbname="yatra";

$conn=mysqli_connect($servername,$username,$pass,$dbname);
	
$sql1="CREATE TABLE users (
 		name VARCHAR(30) NOT NULL,
 		mobile int(11) NOT NULL,
 		username VARCHAR(30) NOT NULL,
 		password VARCHAR(50) NOT NULL
 		)";  
$result=mysqli_query($conn,$sql1);
echo mysqli_error($conn);
?>		