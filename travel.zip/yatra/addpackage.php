<?php
$pid =$_POST['pid'];
$destination=$_POST['destination'];
$distance=$_POST['distance'];
$stayamount=$_POST['stayamount'];
$foodamount=$_POST['foodamount'];
$busamount=$_POST['busamount'];
$trainamount=$_POST['trainamount'];
$airplaneamount=$_POST['airplaneamount'];
$filename = $_FILES["image"]["name"];
$tempname = $_FILES["image"]["tmp_name"];
$folder = "images/".$filename;
//echo $filename;
move_uploaded_file($tempname, $folder);


	$servername="localhost";
	$username="root";
	$pass="";
	$dbname="yatra";

$conn=mysqli_connect($servername,$username,$pass,$dbname);
$sql="INSERT INTO packages VALUES('$pid','$destination','$distance','$stayamount','$foodamount','$busamount','$trainamount','$airplaneamount','$filename')";
 mysqli_query($conn,$sql);
 header("Location:packages.php");		
//echo"<script>window.Location='packages.php'</script>";