<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style>
body{
margin:0px;
padding :0px;
background-color:#edf1f7;
}
#logo{
	height:100%;
	width:15%;
	float: left;
	margin-left: 5%;
	margin-top: 10px;
}
#logo img{
	height:80%;
	width:100%;
}

#opt {
height:75px;
width:100%;
background-color:white;
font-family:arial;
font-weight:bold;
}
#opt ul{
text-decoration:none;
list-style:none;
}
a{
float:right;
text-decoration:none;
color:red;
padding:20px 30px;
margin-left:30px;
font-family:arial;
}
a:hover{
background-color:white;
color:black;
border-bottom: 3px solid red;

}
a.active{
background-color:white;
color:black;
border-bottom: 3px solid red;

}
*{
margin:0px;
padding:0px;
}
#three2{
	border: 3px solid red;
	border-radius: 3px;
font-family:arial;
height:420px;
width:300px;
margin-top:75px;
float:left;
color:red;
padding:10px;
margin-left:100px;
background-color:#edf1f7;
opacity: 0.9;

font-size:30px;
}
#three2:hover{
	opacity:1;
}
input[type="text"],input[type="password"],input[type="number"],input[type="email"]
{
	border-radius: 3px;
margin-top:20px;
height:20px;
width:89%;
background-color:white;
color:black;
font-family:arial;
padding:10px;
margin-left:5px;
border:0px;
border-bottom: 1px solid grey;
}
input[type="submit"]
{
width:100px;
height:40px;
background-color:#edf1f7;
padding:10px;
color:red;
border-radius:20px;
margin-left: calc(50% - 50px);
font-family:verdana;
font-size: 15px;
border:1px solid red;
}
input[type="submit"]:hover
{
width:100px;
height:40px;
padding:10px;
color:red;
border-radius:20px;
cursor:pointer;
}
input::placeholder{
	font-family:verdana;
	font-style: bold;
	font-size: 15px;
	color:black;
}
#four{
	float: right;
	height:400px;
	width:55%;
	margin-top:10%;
	font-family:courier new;
	font-size: 70px;
	color:black;
}
.animated {
	font-family:courier new;
	font-size: 70px;
	
            height: 100p%;
            width: 100%;
            -webkit-animation-duration: 10s;
            animation-duration: 10s;
            -webkit-animation-fill-mode: both;
            animation-fill-mode: both;
            animation-delay: 0s;
            color: black;
         }
         
         @-webkit-keyframes fadeIn {
            0% {opacity: 0;}
            100% {opacity: 1;}
         }
         
         @keyframes fadeIn {
            0% {opacity: 0;}
            100% {opacity: 1;}
         }
         
         .fadeIn {
            -webkit-animation-name: fadeIn;
            animation-name: fadeIn;
         }

	</style>
</head>
<body>
<div id="opt">
	<div id="logo"><img src="company.png"></div>
<nav>
<ul>
<li><a href="login.html" class="active">LOGIN</a></li>
<li><a href="contact.php">CONTACT US</a></li>
<li><a href="about.php">ABOUT US</a></li>
<li><a href="index.php" >HOME</a></li>
</ul>
</nav>
</div>
<div id="four"><div id = "animated-example" class = "animated fadeIn">"Be fearless in the pursuit of what sets your soul on fire."</div></div>
<div id="three2">
<center><b>Sign Up Here</b></center> 
<form  method="POST">
<input type="text" name="n1"  placeholder="Name"> 
<input type="number" name="n2"  placeholder="Mobile">
<input type="Email" name="n6"  placeholder="Email">
<input type="text" name="n3"  placeholder="Username">
<input type="password" name="n4"  placeholder="Password"><br><br>
<input type="submit" name="n5"   value="Create!">
</div>
</div>

</body>
</html>
 <?php

$name=filter_input(INPUT_POST,'n1');
$phone=filter_input(INPUT_POST,'n2');
$uname=filter_input(INPUT_POST,'n3');
$pass=filter_input(INPUT_POST,'n4');
$submit=filter_input(INPUT_POST,'n5');
$Email=filter_input(INPUT_POST,'n6');


if(!empty($submit)){
if(!empty($name)){
if(!empty($phone)){
if(!empty($Email)){
if(!empty($uname)){
if(!empty($pass)){

$dbservername="localhost";
$dbusername="root";
$dbpassword="";
$dbname="yatra";
$conn=mysqli_connect($dbservername,$dbusername,$dbpassword,$dbname);


	$sql="select * from users where username='$uname';";
	$result=mysqli_query($conn,$sql);
	$resultcheck=mysqli_num_rows($result);
	
	if(!preg_match("/[a-zA-Z]+$/", $name))
		{
			echo"<script> alert('Name is invalid')</script>";
			echo "<script> window.location = 'signup.php'</script>";
			exit();
		}
		
	if(!preg_match("/[a-zA-Z0-9]+$/", $uname))
		{
			echo"<script> alert('Username is invalid')</script>";
			echo "<script> window.location = 'signup.php'</script>";
			exit();
		}
	if (!preg_match("/[1-9]{10}+$/", $phone)) 
		{
			echo"<script> alert('phone is invalid')</script>";
			echo "<script> window.location = 'signup.php'</script>";
			exit();
		}

	if($resultcheck>0)
		{
		echo"<script> alert('please enter another username')</script>";
		echo "<script> window.location = 'signup.php'</script>";
    	exit();
		}	      
     		
	$sql1="INSERT INTO users (name,mobile,email,username,password) values('$name','$phone','$Email','$uname','$pass')";
		mysqli_query($conn,$sql1);
  echo"<script>alert('your account has been created')</script>";
echo "<script> window.location = 'user.php'</script>";

			exit();

				
}
else
{
echo"<script>alert('please enter the password')</script>";
echo "<script> window.location = 'signup.php'</script>";}
}
else
{
echo"<script>alert('please enter the username')</script>";
echo "<script> window.location = 'signup.php'</script>";}
}
else
{
echo"<script>alert('please enter your Email id')</script>";
echo "<script> window.location = 'signup.php'</script>";}
}

else
{
echo"<script>alert('please enter your phone number')</script>";
echo "<script> window.location = 'signup.php'</script>";}
}
else
{
echo"<script>alert('please enter your name')</script>";
echo "<script> window.location = 'signup.php'</script>";}
}
?>