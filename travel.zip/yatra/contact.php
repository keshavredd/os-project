<!DOCTYPE html>
<html>
<head>
<style>
body{
margin:0px;
padding :0px;
background-color:white;
}
#one{
height:50vh;
width:100%;
background-image:url(pic.jpg);
background-size:cover;

}
/*display:table;
background-attachment:fixed;
*/
#one2{
	background-color:black;
	height:100%;
	width:100%;
	opacity:0.6;
}
h1{
font-family:arial black;
font-size:70px;
color:white;
margin-top:100px;
text-align:center;
display:table-cell;
vertical-align:middle;
}

#opt {
height:75px;
width:100%;
background-color:white;
font-family:arial;
font-weight:bold;
}
#opt ul{
text-decoration:none;
list-style:none;
}
a{
float:right;
text-decoration:none;
color:red;
padding:20px 30px;
margin-left:30px;
font-family:arial;
}
a:hover{
background-color:white;
color:black;
border-bottom: 3px solid red;

}
a.active{
background-color:white;
color:black;
border-bottom: 3px solid red;

}
*{
margin:0px;
padding:0px;
}
#logo{
	height:100%;
	width:15%;
	float: left;
	margin-left: 5%;
	margin-top: 10px;
}
#logo img{
	height:80%;
	width:100%;
}

#t2{
height:20vh;
width:20%;
margin-top:50px;
margin-right:100px;
margin-bottom: 100px;
padding:20px;
float:right;
font-family:arial;
color:black;
box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}
#contact
{
 height:20vh;
 width:60%;
 float:left;
 margin-top:50px;
 margin-left: 50px;
 padding:20px;
 font-family: verdana;
 font-weight: bold;
 line-height: 30px;
box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}
#contact input[type=email]
{
margin-top: 50px;
height:20px;
width:80%;
padding:5px;
}
#contact input[type=submit]
{
background-color:dodgerblue;
height:33px;
width:100px;
color:white;
font-family:arial;
border-radius: 3px;
font-weight: bold;
font-size:15px;
margin-left: 20px;
border:none;
cursor:pointer;
}
#map{
	padding-top:1vh;
	margin-left:-230%;
	padding-bottom: 5vh;
}
#office{
	margin-left:-175%;
	margin-top:15vh;
	padding-bottom: 5vh;
	font-family: verdana;
	font-size:25px;
}
</style>
</head>
<body>
<div id="opt">
	<div id="logo"><img src="company.png"></div>
<nav>
<ul>

<li><a href="login.html">LOGIN</a></li>
<li><a href="contact.php" class="active">CONTACT US</a></li>
<li><a href="about.php">ABOUT US</a></li>
<li><a href="index.php" >HOME</a></li>

</ul>
</nav>
</div>

<div id="one">
	<div id="one2"> 
	</div>
</div>
<div id="contact">
	<p><center><h3>CONTACT FORM</h3></center></p>
	<hr width="100%" color="red" align="left">
	<form method="POST"> <input type="email" placeholder="Enter your email id, we will contact you" name="mail">
		<input type="submit" name="submit" value="Enter">
	</form>
</div>
<div id="t2">
<h3><b><center>OPENING HOURS</center></b></h3>	
<hr width="100%" color="red" align="left">
<div id="t3">
<br><br>
BOOKING&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; SUPPORT
<br><br>24<small>x</small>7&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;24<small>x</small>7
</div>
<p id="office">OUR OFFICE ON MAP</p>
<iframe id="map" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3410.755444683119!2d75.70284421462406!3d31.255192667316514!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x391a5a594d22b88d%3A0x4cc934c58d0992ec!2sLovely%20Professional%20University!5e0!3m2!1sen!2sin!4v1570820376535!5m2!1sen!2sin" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
<?php
$email=filter_input(INPUT_POST,'mail');
$submit=filter_input(INPUT_POST,'submit');

if(!empty($submit)){
if(!empty($email)){


$db = mysqli_connect("localhost", "root", "", "yatra");
$sql ="INSERT INTO CONTACT VALUES ('$email')";
mysqli_query($db,$sql);
mysqli_error($db);
echo"<script>alert('Thank you!!!')</script>";
echo "<script> window.location = 'home.php'</script>";
}
else{
	echo"<script>alert('please enter the mail id')</script>";
	echo "<script> window.location = 'contact.php'</script>";}
}
?>
</body>
</html>