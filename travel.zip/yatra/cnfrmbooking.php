<?php 
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<style>
body{
margin:0px;
padding :0px;
background-color:#edf1f7;
}
#one{
height:50vh;
width:100%;
background-image:url(pic.jpg);
background-size:cover;

}
/*display:table;
background-attachment:fixed;
*/
#one2{
	background-color:black;
	height:100%;
	width:100%;
	opacity:0.6;
}
h1{
font-family:arial black;
font-size:70px;
color:white;
margin-top:100px;
text-align:center;
display:table-cell;
vertical-align:middle;
}

#opt {
height:75px;
width:100%;
background-color:white;
font-family:arial;
font-weight:bold;
}
#opt ul{
text-decoration:none;
list-style:none;
}
a{
float:right;
text-decoration:none;
color:red;
padding:20px 30px;
margin-left:30px;
font-family:arial;
}
a:hover{
background-color:white;
color:black;
border-bottom: 3px solid red;

}
a.active{
background-color:white;
color:black;
border-bottom: 3px solid red;

}
*{
margin:0px;
padding:0px;
}
#logo{
	height:100%;
	width:15%;
	float: left;
	margin-left: 5%;
	margin-top: 10px;
}
#logo img{
	height:80%;
	width:100%;
}

#cards{
	height:auto;
	width:200px;
	
	margin-left:40%;
	font-family: verdana;

}
#cards button
{
background-color:dodgerblue;
height:30px;
width:100px;
color:white;
font-family: verdana;
border-radius: 3px;
font-weight: bold;
font-size:15px;
margin-left: 20px;
border:none;
cursor:pointer;
}
#amount{
	height:50px;
	width:400px;
	margin-left: 40%;
	font-family: verdana;
	font-size:15px;
	margin-top:5%;
}
</style>
</head>
<body>
<div id="opt">
	<div id="logo"><img src="company.png"></div>
<nav>
<ul>

<li><a href="logout.php">Log out</a></li>
<li><a href="ulandingpage.php" class="active">Packages</a></li>

</ul>
</nav>
</div>

<div id="one">
	<div id="one2"> 
	</div>
</div>

<?php
$total =$_POST['tamount'];
$startdate=$_POST['startdate'];
$travelcost=$_POST['travelcost'];
$foodcost=$_POST['foodcost'];
$adults=$_POST['ad'];
$children=$_POST['cd'];

$_SESSION['people']=$adults+$children;
$_SESSION['startdate']=$startdate;
$_SESSION['travelcost']=$travelcost;
$_SESSION['foodcost']=$foodcost;
$_SESSION['totalcost']=$total;
echo"<div id='amount'> Total amount :-".$total."</div>";
?>

<div id="cards">
		<input type="radio" name="card" id="credit">Credit card<br><br>
		<input type="radio" name="card" id="debit">Debit card<br><br><br>
		<button onclick="check()">Pay</button>
</div>
	<script >
		function check() {

			if(document.getElementById('credit').checked)
			{
				window.location='credit.php';
			}
			if(document.getElementById('debit').checked)
			{
				window.location='debit.php';
			}
		}
	</script>
</div>

</body>
</html>
