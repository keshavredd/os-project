<html>
<head>
<title>Login Form Design</title>
    <link rel="stylesheet" type="text/css" href="stylelogin.css">
<style>
    body{
    margin: 0;
    padding: 0;
    background-image: url(pic1.jpg);
    background-repeat: no-repeat;
    background-size: cover;
    background-position: center;
    font-family: sans-serif;
    background-color: f7f3f0;
}

.loginbox{
  box-shadow: 10px 10px 8px #888888;
    width: 320px;
    height: 380px;
    background:white;
    color:black;
    top: 45%;
    left: 50%;
    transform: translate(-50%,-50%);
    box-sizing: border-box;
    padding: 80px 30px;
    position: relative;
  -webkit-animation: mymove 3s;  /* Safari 4.0 - 8.0 */
  -webkit-animation-fill-mode: forwards; /* Safari 4.0 - 8.0 */
  animation: mymove 2s;
  animation-fill-mode: forwards;
  opacity: 0.9;
  border-radius: 3px;
}
.loginbox:hover{
  opacity: 1;
}
@-webkit-keyframes mymove {
  from {left: 0px;}
  to {left: 45%; }
}

@keyframes mymove {
  from {left: 0px;}
  to {left: 45%;}
}

.avatar{
    width: 100px;
    height: 100px;
    border-radius: 50%;
    position: absolute;
    top: -50px;
    left: calc(50% - 50px);
}

h1{
    margin: 0;
    padding: 0 0 20px;
    text-align: center;
    font-size: 22px;
}

.loginbox p{
    margin: 0;
    padding: 0;
    font-weight: bold;
}

.loginbox input{
    width: 100%;
    margin-bottom: 20px;
}

.loginbox input[type="text"], input[type="password"]
{
    border: none;
    border-bottom: 1px solid #fff;
    background-color: f7f3f0;
    outline: none;
    height: 40px;
    color: black;
    font-size: 16px;
    padding:10px;
}
.loginbox input[type="submit"]
{
    border: none;
    outline: none;
    height: 40px;
    background: #fb2525;
    color: #fff;
    font-size: 18px;
    border-radius: 20px;
    text-align: center;
}
.loginbox input[type="submit"]:hover
{
    cursor: pointer;
    background: #fc7505;
    
}
.loginbox a{
    text-decoration: none;
    font-size: 12px;
    line-height: 20px;
    color:red;
    margin-left:0px;

}

.loginbox a:hover
{
    color: #ffc107;
}


label {
  display: block;
  padding-left: 20px;
  text-indent: -15px;
  padding-bottom: 15px;
}
.loginbox input[type="checkbox"]
{
  width: 13px;
  height: 13px;
  padding: 0;
  margin:0;
  vertical-align: bottom;
  position: relative;
  top: -1px;
}
#opt {
height:75px;
width:100%;
background-color:white;
font-family:arial;
font-weight:bold;
}
#opt ul{
text-decoration:none;
list-style:none;
}
#opt a{
float:right;
text-decoration:none;
color:red;
padding:20px 30px;
margin-left:30px;
font-family:arial;
}
#opt a:hover{
background-color:white;
color:black;
border-bottom: 3px solid red;

}
#opt a.active{
background-color:white;
color:black;
border-bottom: 3px solid red;

}
*{
margin:0px;
padding:0px;
}
#logo{
    height:100%;
    width:15%;
    float: left;
    margin-left: 5%;
    margin-top: 10px;
}#logo img{
  height:80%;
  width:100%;
}

</style>
<body>
    <body>
<div id="opt">
    <div id="logo"><img src="company.png"></div>
<nav>
<ul>

<li><a href="login.html" class="active">LOGIN</a></li>
<li><a href="contact.php">CONTACT US</a></li>
<li><a href="about.php">ABOUT US</a></li>
<li><a href="index.php" >HOME</a></li>

</ul>
</nav>
</div>

    
    <div class="loginbox">
    <img src="avatar.png" class="avatar">
        <h1>ADMIN</h1>
        <form method="post" >
            <p>Username</p>
            <input type="text" name="n1">
            <p>Password</p>
            <input type="password" name="n2">
            <input type="submit" name="submit" value="Login">
            
        </form>
        
    </div>

</body>
</head>
</html>
<?php
$username=filter_input(INPUT_POST,'n1');
$password=filter_input(INPUT_POST,'n2');
$submit=filter_input(INPUT_POST,'submit');
if(!empty($submit)){
if(!empty($username)){
if(!empty($password)){


$dbservername="localhost";
$dbusername="root";
$dbpassword="";
$dbname="yatra";
$conn=mysqli_connect($dbservername,$dbusername,$dbpassword,$dbname);


    $sql="SELECT * FROM admins WHERE username='$username'";
    $result=mysqli_query($conn,$sql);
    $row= mysqli_fetch_assoc($result);

            if($password == $row['password'])
            {
                 
                  if($username == $row['username'])
                    session_start();
                    $_SESSION['username']=$username;
                    header("Location:alandingpage.php");
                
            }
            else{echo "<script>alert('username or password invalid')</script>";
            echo "<script> window.location = 'admin.php'</script>";}

        
}else{echo "<script>alert('Enter the Password')</script>";
echo "<script> window.location = 'admin.php'</script>";}
}else{echo "<script>alert('Enter the Username')</script>";
echo "<script> window.location = 'admin.php'</script>";}

}?> 