<!DOCTYPE html>
<html>
<head>
<style>
body{
margin:0px;
padding :0px;
background-color:#edf1f7;
}
#one{
height:50vh;
width:100%;
background-image:url(pic.jpg);
background-size:cover;

}
/*display:table;
background-attachment:fixed;
*/
#one2{
	background-color:black;
	height:100%;
	width:100%;
	opacity:0.6;
}
h1{
font-family:arial black;
font-size:70px;
color:white;
margin-top:100px;
text-align:center;
display:table-cell;
vertical-align:middle;
}

#opt {
height:75px;
width:100%;
background-color:white;
font-family:arial;
font-weight:bold;
}
#opt ul{
text-decoration:none;
list-style:none;
}
a{
float:right;
text-decoration:none;
color:red;
padding:20px 30px;
margin-left:30px;
font-family:arial;
}
a:hover{
background-color:white;
color:black;
border-bottom: 3px solid red;

}
a.active{
background-color:white;
color:black;
border-bottom: 3px solid red;

}
*{
margin:0px;
padding:0px;
}
#logo{
	height:100%;
	width:15%;
	float: left;
	margin-left: 5%;
	margin-top: 10px;
}
#logo img{
	height:80%;
	width:100%;
}
   	.article-container{
   		width:80%;
   margin-top:50px;
margin-left:10%;
background-color: red;
height:auto;
   	}
   	.article-box{
   		 float:left;
         text-align: center;
   		width:30%;
   height:auto;
         background-color: #f7f3f0;
margin-left:20px;
margin-top: 20px;
margin-bottom: 10vh;
box-shadow:5px 5px 15px grey;
background-repeat: no-repeat;
color:black;
border-radius:5px;
}
.sbutton img{
 
   width:100%;
 object-fit: cover;
 border-radius: 5px 5px 0px 0px;
}
.sbutton{
	border:0px;
	height:100%;
	width:100%;
	cursor: pointer;
	border-radius:5px;
}
.sbutton p{
	font-size:20px;
	font-family: verdana;
	padding-bottom: 5px;
}
</style>
</head>
<body>
<div id="opt">
	<div id="logo"><img src="company.png"></div>
<nav>
<ul>

<li><a href="login.html">LOGIN</a></li>
<li><a href="contact.php">CONTACT US</a></li>
<li><a href="about.php">ABOUT US</a></li>
<li><a href="home.php" class="active">HOME</a></li>

</ul>
</nav>
</div>

<div id="one">
	<div id="one2"> 
	</div>
</div><br><br><br>
<h3 style="font-family: verdana;"><center> Some of the popular Destinations </center></h3>
<div class="article-container">

<?php
$db = mysqli_connect("localhost", "root", "", "yatra");
$sql ="SELECT * FROM packages";
$result = mysqli_query($db,$sql);
$queryResults = mysqli_num_rows($result);

if ($queryResults > 0) {
    
    while($row=mysqli_fetch_assoc($result))
    {
      echo"<div class='article-box'>
            <form method='POST' action='individual.php'>
            <input type= 'hidden' name='naam' value=".$row['destination'].">

            <button class='sbutton' type='submit'><img src=images/".$row['image'].">
           <br> <p>".$row['destination']."</p></button>
    </form></div>";
  
    }
  }
 
?>
</div>
</body>
</html>