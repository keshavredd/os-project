<?php 
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<style>
body{
margin:0px;
padding :0px;
background-color:#edf1f7;
}
/*display:table;
background-attachment:fixed;
*/
h1{
font-family:arial black;
font-size:70px;
color:white;
margin-top:100px;
text-align:center;
display:table-cell;
vertical-align:middle;
}

#opt {
height:75px;
width:100%;
background-color:white;
font-family:arial;
font-weight:bold;
}
#opt ul{
text-decoration:none;
list-style:none;
}
#opt a{
float:right;
text-decoration:none;
color:red;
padding:20px 30px;
margin-left:30px;
font-family:arial;
}
#opt a:hover{
background-color:white;
color:black;
border-bottom: 3px solid red;

}
#opt a.active{
background-color:white;
color:black;
border-bottom: 3px solid red;
}
a{
  padding:10px;
  text-decoration: none;
  font-family: verdana;

}
*{
margin:0px;
padding:0px;
}
#logo{
	height:100%;
	width:15%;
	float: left;
	margin-left: 5%;
	margin-top: 10px;
}
#logo img{
  height:80%;
  width:100%;
}

table{
	margin-left:25%;
	margin-top:3%;
	background-color: white;
}
table ,td ,th{
	padding:10px;
	font-family: verdana;
	border:2px solid black;
	border-collapse: collapse;
}
.btn
{
background-color:dodgerblue;
height:30px;
width:100px;
color:white;
font-family: verdana;
border-radius: 3px;
font-weight: bold;
font-size:15px;
margin-left: 20px;
border:none;
cursor:pointer;
}
.btn2{
background-color:dodgerblue;
height:30px;
width:200px;
color:white;
font-family: verdana;
border-radius: 3px;
font-weight: bold;
font-size:15px;
margin-left: 20px;
border:none;
cursor:pointer;
}
</style>
</head>
<body>
<div id="opt">
	<div id="logo"><img src="company.png"></div>
<nav>
<ul><?php 
 if(!$_SESSION['username']==''){
echo"<li><a href='logout.php'>Log out</a></li>";}
?>
<li><a href="ulandingpage.php" class="active">Packages</a></li>
</ul>
</nav>
</div>
</body>
</html>
<?php

if($_SESSION['username']=='')
{
  echo"<script>window.location='index.php'</script>";
}
//echo$_SESSION['username'];
$db = mysqli_connect("localhost", "root", "", "yatra");

$search= $_POST['naam'];
$sql ="SELECT * FROM packages Where  destination LIKE '%$search%'";
$result = mysqli_query($db,$sql);
$queryResults = mysqli_num_rows($result);

if ($queryResults > 0) {
    $row=mysqli_fetch_assoc($result);
    $_SESSION['place']=$row['destination'];
    
    $_SESSION['stayamount']=$row['stayamount'];

    echo "<table>";
      echo "<tr>
			<td rowspan='7'><img src='images/".$row['image']."'></td> <td> Destination :- ".$row['destination']."</td></tr>
      		
          <tr><td>".$row['distance']." Kms<br></td></tr>
      		
          <tr><td> No of Adults :-<input type ='number' id ='adults'><br> No of childrens :-<input type ='number' id ='children'></td></tr>

      		<tr><td>Stay amount:-".$row['stayamount']."</td></tr>
      		
          <tr><td>Food<br> 
      		<input type='radio' name='food' id='yes'>yes
      		<input type='radio' name='food' id='no'>no </td></tr>
      		
          <tr><td>travelling<br> 
      		<input type='radio' name='travel' id='bus'>bus
      		<input type='radio' name='travel' id='train'>train
      		<input type='radio' name='travel' id='airplane'>airplane</td></tr>
      		
          <tr><td>Total :-<p id='total'></p><br>
      		<button  class='btn'onclick='check()'>calculate</button></td></tr>
      		
          <form action='cnfrmbooking.php' method='POST'>
      		<tr><td>Start date <input type='date' name='startdate' required></td>
          <td><a href='https://www.zomato.com'>Zomato</a><a href='https://www.uber.com/in/en/'>Uber</a></td></tr>
      		
          <input type='hidden'  name='foodcost' id='foodamount'>
      		<input type='hidden'  name='travelcost' id='travelamount'>
          <input type='hidden'  name='persons' id='persons'>
      		<input type='hidden'  name='tamount' id='totalamount'>
          <input type='hidden' name='ad' id='ad'>
          <input type='hidden' name='cd' id='cd'>
      		
          <tr><td colspan='2'><center><input type ='submit'  class='btn2' name='submit' value='Confirm booking'></center></form>
          </td></tr>";
//$tpersons="<script>document.getElementById('adults').value</script>";
//$tpersons+="<script>document.getElementById('children').value</script>";

    echo"</table>";
    echo"<script>
    function check()
    {
      var adults = (document.getElementById('adults').value);
      var children = (document.getElementById('children').value)*.5;
document.getElementById('ad').value = adults;
document.getElementById('cd').value = children;

var adults=parseInt(adults, 10);
var children=parseInt(children, 10);
var pep=adults+children;

    var  total = ".$row['stayamount'].";
    
if(document.getElementById('yes').checked) {
	var food = ".$row['foodamount'].";
  	total=total+food;
  	document.getElementById('foodamount').value = food;
}
if(document.getElementById('no').checked) {
 	var food = 0;
 	total=total+food;
 	document.getElementById('foodamount').value = food;
}
if(document.getElementById('bus').checked) {
	var travel = ".$row['busamount'].";
  	total=total+travel;
  	document.getElementById('travelamount').value = travel;
}
 if(document.getElementById('train').checked) {
 	var travel = ".$row['trainamount'].";
 	total=total+travel;
 		document.getElementById('travelamount').value = travel;

}
 if(document.getElementById('airplane').checked) {
 	var travel = ".$row['airplaneamount'].";
 	total=total+travel;
 		document.getElementById('travelamount').value = travel;
}
total=total*pep;
document.getElementById('totalamount').value = total;
document.getElementById('total').innerHTML = total;
}
</script>";
  }
?>